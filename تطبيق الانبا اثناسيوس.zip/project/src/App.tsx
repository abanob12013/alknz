import { useState, useEffect, useRef } from 'react';
import { Logo } from './components/Logo';
import { Auth } from './components/Auth';
import { Profile } from './components/Profile';
import { Settings } from './components/Settings';
import { TaskGrid } from './components/TaskGrid';
import { DailyChart } from './components/DailyChart';
import AdminDashboard from './components/AdminDashboard';
import { Task, DailyAnalysis, Settings as SettingsType, User, AuthState, Message } from './types';
import { 
  Menu, 
  Info, 
  FileText, 
  Mail, 
  Home, 
  User as UserIcon, 
  BarChart as ChartBar, 
  Settings as SettingsIcon,
  MessageSquare,
  Bell,
  Trash2,
  Coins,
  LogOut
} from 'lucide-react';

// تعريف مصفوفة النقاط حسب الترتيب المطلوب
const taskPoints = [1, 1, 1, 1, 1, 1, 1, 5, 10, 3, 7, 2, 1, 6, 8, 5, 2];

const cleanupStorage = () => {
  try {
    const users = JSON.parse(localStorage.getItem('users') || '{}');
    
    // تقليل عدد بيانات اليوم والإشعارات لكل مستخدم
    Object.keys(users).forEach(userId => {
      const user = users[userId];
      
      // الاحتفاظ بآخر 30 يوم من البيانات
      if (user.dailyData && user.dailyData.length > 30) {
        user.dailyData = user.dailyData
          .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
          .slice(0, 30);
      }
      
      // الاحتفاظ بآخر 50 إشعار
      if (user.notifications && user.notifications.length > 50) {
        user.notifications = user.notifications
          .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
          .slice(0, 50);
      }
    });
    
    localStorage.setItem('users', JSON.stringify(users));
  } catch (error) {
    console.error('Error cleaning up storage:', error);
  }
};

const safeSetItem = (key: string, value: any) => {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (error: any) {
    if (error.name === 'QuotaExceededError') {
      cleanupStorage();
      try {
        localStorage.setItem(key, JSON.stringify(value));
      } catch (retryError) {
        console.error('Storage quota exceeded even after cleanup:', retryError);
        alert('Storage limit reached. Please clear some data.');
      }
    } else {
      console.error('Error saving to storage:', error);
    }
  }
};

function App() {
  const [authState, setAuthState] = useState<AuthState>({
    isAuthenticated: false,
    user: null,
    isAdmin: false
  });

  const [settings, setSettings] = useState<SettingsType>({
    fontSize: 16,
    language: 'ar',
    useBiometrics: false,
    darkMode: false
  });

  // تهيئة المهام كمصفوفة فارغة لتفادي الأخطاء
  const [tasks, setTasks] = useState<Task[]>([]);
  const [currentScreen, setCurrentScreen] = useState<'tasks' | 'profile' | 'settings' | 'chart' | 'messages'>('tasks');
  const [menuOpen, setMenuOpen] = useState(false);
  const [dailyData, setDailyData] = useState<DailyAnalysis[]>([]);
  const [notifications, setNotifications] = useState<Message[]>([]);
  const [showNotifications, setShowNotifications] = useState(false);
  const [totalPoints, setTotalPoints] = useState(0);

  const menuRef = useRef<HTMLDivElement>(null);
  const notificationRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setMenuOpen(false);
      }
      if (notificationRef.current && !notificationRef.current.contains(event.target as Node)) {
        setShowNotifications(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  useEffect(() => {
    // عند تهيئة المهام للمستخدمين الجدد، لن نقوم بتعيين قيمة نقاط ثابتة،
    // بل نتركها كما هي (أو يمكن الاحتفاظ بها كـ 10 مثلاً) لأننا سنحسب القيمة الفعلية عند الضغط
    const defaultTasks: Task[] = Array.from({ length: 17 }, (_, i) => ({
      id: i + 1,
      // القيمة هنا لن تُستخدم في احتساب النقاط لأنها ستحسب عند الضغط
      points: 10,
      imageUrl: `https://source.unsplash.com/random/300x200?spiritual,${i}`,
      completed: false,
      lastCompletedAt: null
    }));

    // التحقق من وجود حالة المصادقة في localStorage
    const savedAuth = localStorage.getItem('authState');
    if (savedAuth) {
      const parsedAuth = JSON.parse(savedAuth);
      setAuthState(parsedAuth);
      
      if (parsedAuth.user) {
        const users = JSON.parse(localStorage.getItem('users') || '{}');
        const user = users[parsedAuth.user.id];
        
        if (user) {
          // Check if user is blocked
          if (user.blocked) {
            // Log out blocked user
            setAuthState({
              isAuthenticated: false,
              user: null,
              isAdmin: false
            });
            localStorage.removeItem('authState');
            alert(settings.language === 'ar' 
              ? 'هذا الحساب محظور. يرجى التواصل مع المسؤول.' 
              : 'This account is blocked. Please contact the administrator.');
            return;
          }
          
          // تحميل بيانات المستخدم الخاصة
          setSettings(user.settings || settings);
          setDailyData(user.dailyData || []);
          setNotifications(user.notifications || []);
          
          // تهيئة المهام إن لم تكن موجودة
          if (!user.tasks) {
            user.tasks = defaultTasks;
            users[parsedAuth.user.id].tasks = defaultTasks;
            localStorage.setItem('users', JSON.stringify(users));
          }
          setTasks(user.tasks);
          
          // حساب إجمالي النقاط من البيانات اليومية
          const points = (user.dailyData || []).reduce((acc, day) => acc + day.points, 0);
          setTotalPoints(points);
        }
      }
    }
  }, []);

  const handleLogin = (user: User) => {
    try {
      const users = JSON.parse(localStorage.getItem('users') || '{}');
      const isNewUser = !users[user.id];

      // Check if user is blocked
      if (users[user.id] && users[user.id].blocked) {
        alert(settings.language === 'ar' 
          ? 'هذا الحساب محظور. يرجى التواصل مع المسؤول.' 
          : 'This account is blocked. Please contact the administrator.');
        return;
      }

      const defaultTasks: Task[] = Array.from({ length: 17 }, (_, i) => ({
        id: i + 1,
        points: 10, // قيمة افتراضية ستُحسب لاحقاً عند إتمام المهمة
        imageUrl: `https://source.unsplash.com/random/300x200?spiritual,${i}`,
        completed: false,
        lastCompletedAt: null
      }));

      if (isNewUser) {
        users[user.id] = {
          ...user,
          settings: {
            fontSize: 16,
            language: 'ar',
            useBiometrics: false,
            darkMode: false
          },
          tasks: defaultTasks,
          points: 0,
          dailyData: [],
          notifications: []
        };
        safeSetItem('users', users);
      }

      const newAuthState = {
        isAuthenticated: true,
        user,
        isAdmin: false
      };
      setAuthState(newAuthState);
      safeSetItem('authState', newAuthState);
      safeSetItem('lastLoggedInUser', user.id);

      // تحميل بيانات المستخدم
      const userData = users[user.id];
      setSettings(userData.settings);
      setTasks(userData.tasks);
      setDailyData(userData.dailyData || []);
      setNotifications(userData.notifications || []);
      setTotalPoints(userData.points || 0);
    } catch (error) {
      console.error('Error during login:', error);
      alert('An error occurred during login. Please try again.');
    }
  };

  // حل بديل: عند إتمام المهمة، لا نعتمد على القيمة المخزنة في المهمة (قد تكون ثابتة) 
  // بل نقوم بحساب قيمة النقاط من المصفوفة "taskPoints" باستخدام رقم المهمة
  const handleTaskComplete = (taskId: number) => {
    if (!authState.user) return;

    try {
      const users = JSON.parse(localStorage.getItem('users') || '{}');
      const userData = users[authState.user.id];
      const task = userData.tasks.find((t: Task) => t.id === taskId);

      if (!task) return;

      // التحقق مما إذا كانت المهمة قد اكتملت خلال الـ 24 ساعة الماضية
      if (task.lastCompletedAt) {
        const lastCompletionTime = new Date(task.lastCompletedAt).getTime();
        const currentTime = new Date().getTime();
        const hoursSinceLastCompletion = (currentTime - lastCompletionTime) / (1000 * 60 * 60);

        if (hoursSinceLastCompletion < 24) {
          alert(settings.language === 'ar' 
            ? 'لا يمكن تنفيذ نفس المهمة مرة أخرى قبل مرور 24 ساعة'
            : 'Cannot complete the same task again before 24 hours');
          return;
        }
      }

      // حساب القيمة الفعلية للنقاط من المصفوفة باستخدام رقم المهمة
      const computedPoints = taskPoints[taskId - 1];

      // تحديث حالة المهمة مع تسجيل الوقت وتعيين القيمة المحسوبة للنقاط
      const updatedTasks = userData.tasks.map((t: Task) =>
        t.id === taskId
          ? { ...t, completed: true, lastCompletedAt: new Date().toISOString(), points: computedPoints }
          : t
      );

      // تحديث البيانات اليومية للمستخدم
      const today = new Date().toISOString().split('T')[0];
      const todayData = userData.dailyData.find((d: DailyAnalysis) => d.date.startsWith(today));
      
      let updatedDailyData: DailyAnalysis[];
      if (todayData) {
        if (todayData.completedTasks?.includes(taskId)) {
          alert(settings.language === 'ar'
            ? 'لقد قمت بتنفيذ هذه المهمة بالفعل اليوم'
            : 'You have already completed this task today');
          return;
        }

        updatedDailyData = userData.dailyData.map((d: DailyAnalysis) =>
          d.date.startsWith(today)
            ? {
                ...d,
                points: d.points + computedPoints,
                completedTasks: [...(d.completedTasks || []), taskId],
                taskNames: [
                  ...(d.taskNames || []),
                  {
                    taskId,
                    userId: authState.user!.id,
                    username: authState.user!.username,
                    completedAt: new Date().toISOString()
                  }
                ]
              }
            : d
        );
      } else {
        updatedDailyData = [
          ...userData.dailyData,
          {
            date: today,
            points: computedPoints,
            completedTasks: [taskId],
            taskNames: [{
              taskId,
              userId: authState.user.id,
              username: authState.user.username,
              completedAt: new Date().toISOString()
            }]
          }
        ];
      }

      // ترتيب البيانات اليومية حسب التاريخ
      updatedDailyData.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

      // تحديث بيانات المستخدم في localStorage مع إضافة النقاط المحسوبة
      users[authState.user.id] = {
        ...users[authState.user.id],
        tasks: updatedTasks,
        dailyData: updatedDailyData,
        points: (users[authState.user.id].points || 0) + computedPoints
      };
      safeSetItem('users', users);

      // تحديث الحالة داخل التطبيق
      setTasks(updatedTasks);
      setDailyData(updatedDailyData);
      setTotalPoints(prev => prev + computedPoints);
    } catch (error) {
      console.error('Error completing task:', error);
      alert('An error occurred while completing the task. Please try again.');
    }
  };

  const handleAdminLogin = () => {
    const adminAuthState = {
      isAuthenticated: true,
      user: null,
      isAdmin: true
    };
    setAuthState(adminAuthState);
    localStorage.setItem('authState', JSON.stringify(adminAuthState));
  };

  const handleLogout = () => {
    setAuthState({
      isAuthenticated: false,
      user: null,
      isAdmin: false
    });
    localStorage.removeItem('authState');
    setCurrentScreen('tasks');
    setMenuOpen(false);
    setTotalPoints(0);
  };

  const handleSettingsUpdate = (newSettings: SettingsType) => {
    setSettings(newSettings);
    if (authState.user) {
      const users = JSON.parse(localStorage.getItem('users') || '{}');
      users[authState.user.id] = {
        ...users[authState.user.id],
        settings: newSettings
      };
      localStorage.setItem('users', JSON.stringify(users));
    }
  };

  const handleProfileUpdate = (updatedUser: User) => {
    const newAuthState = {
      ...authState,
      user: updatedUser
    };
    setAuthState(newAuthState);
    localStorage.setItem('authState', JSON.stringify(newAuthState));
  };

  const handleNotificationRead = (messageId: string) => {
    const updatedNotifications = notifications.map(notification =>
      notification.id === messageId
        ? { ...notification, read: true }
        : notification
    );
    setNotifications(updatedNotifications);

    if (authState.user) {
      const users = JSON.parse(localStorage.getItem('users') || '{}');
      users[authState.user.id] = {
        ...users[authState.user.id],
        notifications: updatedNotifications
      };
      localStorage.setItem('users', JSON.stringify(users));
    }
  };

  const handleDeleteNotification = (messageId: string) => {
    const updatedNotifications = notifications.filter(msg => msg.id !== messageId);
    setNotifications(updatedNotifications);

    if (authState.user) {
      const users = JSON.parse(localStorage.getItem('users') || '{}');
      users[authState.user.id] = {
        ...users[authState.user.id],
        notifications: updatedNotifications
      };
      localStorage.setItem('users', JSON.stringify(users));
    }
  };

  const handleMenuClick = (screen: 'tasks' | 'profile' | 'settings' | 'chart' | 'messages') => {
    setCurrentScreen(screen);
    setMenuOpen(false);
  };

  if (!authState.isAuthenticated) {
    return (
      <Auth
        onLogin={handleLogin}
        onAdminLogin={handleAdminLogin}
        language={settings.language}
        useBiometrics={settings.useBiometrics}
      />
    );
  }

  if (authState.isAdmin) {
    return (
      <AdminDashboard
        onLogout={handleLogout}
        language={settings.language}
      />
    );
  }

  return (
    <div 
      className={`min-h-screen ${settings.darkMode ? 'dark bg-gray-900 text-white' : 'bg-gray-100'}`}
      dir={settings.language === 'ar' ? 'rtl' : 'ltr'}
    >
      <header className={`${settings.darkMode ? 'bg-gray-800' : 'bg-white'} shadow-md p-4 fixed w-full top-0 z-40`}>
        <div className="container mx-auto flex justify-between items-center">
          <div className={`w-1/3 flex ${settings.language === 'ar' ? 'justify-start' : 'justify-end'}`}>
            <button
              onClick={() => setMenuOpen(!menuOpen)}
              className="menu-button p-2 hover:bg-gray-100 rounded-full"
            >
              <Menu size={24} />
            </button>
          </div>

          <div className="w-1/3 flex justify-center">
            <div className="flex flex-col items-center">
              <Logo onClick={() => setCurrentScreen('tasks')} />
              <div className={`mt-2 flex items-center ${settings.darkMode ? 'text-white' : 'text-gray-800'}`}>
                <Coins className={`${settings.language === 'ar' ? 'ml-2 animate-bounce' : 'mr-2 animate-bounce'}`} size={20} />
                <span className="font-bold text-xl">{totalPoints}</span>
                <span className="ml-2">{settings.language === 'ar' ? 'نقطة' : 'points'}</span>
              </div>
            </div>
          </div>

          <div className={`w-1/3 flex ${settings.language === 'ar' ? 'justify-end' : 'justify-start'}`}>
            <div className="relative" ref={notificationRef}>
              <button
                onClick={() => setShowNotifications(!showNotifications)}
                className="p-2 hover:bg-gray-100 rounded-full"
              >
                <Bell size={ 24} />
                {notifications.some(n => !n.read) && (
                  <span className="absolute top-0 right-0 bg-red-500 w-3 h-3 rounded-full" />
                )}
              </button>
              {showNotifications && (
                <div 
                  className={`absolute top-12 ${settings.language === 'ar' ? 'left-0' : 'right-0'} w-80 max-h-96 overflow-y-auto ${
                    settings.darkMode ? 'bg-gray-800' : 'bg-white'
                  } shadow-lg rounded-lg p-4 z-50`}
                  style={{
                    animation: `${settings.language === 'ar' ? 'slideInLeft' : 'slideInRight'} 0.3s ease-out`
                  }}
                >
                  {notifications.length === 0 ? (
                    <p className="text-center text-gray-500">
                      {settings.language === 'ar' ? 'لا توجد إشعارات' : 'No notifications'}
                    </p>
                  ) : (
                    notifications.map((message) => (
                      <div
                        key={message.id}
                        className={`p-4 rounded-lg mb-2 ${
                          message.read 
                            ? settings.darkMode ? 'bg-gray-700' : 'bg-gray-50'
                            : settings.darkMode ? 'bg-blue-900' : 'bg-blue-50'
                        }`}
                      >
                        <div className="flex justify-between items-start">
                          <div className="flex-1">
                            <p className="font-semibold">{message.spiritualMessage}</p>
                            <p className="mt-2">{message.notification}</p>
                            <p className="text-sm text-gray-500 mt-2">
                              {new Date(message.timestamp).toLocaleString(
                                settings.language === 'ar' ? 'ar-EG' : 'en-US'
                              )}
                            </p>
                          </div>
                          <button
                            onClick={() => handleDeleteNotification(message.id)}
                            className="text-red-500 hover:text-red-700 p-1 transition-colors duration-200"
                            title={settings.language === 'ar' ? 'حذف الرسالة' : 'Delete message'}
                          >
                            <Trash2 size={16} />
                          </button>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      </header>

      <div 
        ref={menuRef}
        className={`fixed ${settings.language === 'ar' ? 'right-0' : 'left-0'} h-full w-64 z-50 transition-transform duration-300 ease-in-out ${
          menuOpen ? 'translate-x-0' : settings.language === 'ar' ? 'translate-x-full' : '-translate-x-full'
        }`}
        style={{ top: '80px' }}
      >
        <nav className={`menu-content h-full ${settings.darkMode ? 'bg-gray-800' : 'bg-white'} shadow-lg p-4`}>
          <ul className="space-y-2">
            <li>
              <button
                onClick={() => handleMenuClick('tasks')}
                className="w-full p-2 hover:bg-gray-100 rounded flex items-center"
              >
                <Home size={18} className={settings.language === 'ar' ? 'ml-2' : 'mr-2'} />
                <span>{settings.language === 'ar' ? 'المهام' : 'Tasks'}</span>
              </button>
            </li>
            <li>
              <button
                onClick={() => handleMenuClick('messages')}
                className="w-full p-2 hover:bg-gray-100 rounded flex items-center"
              >
                <MessageSquare size={18} className={settings.language === 'ar' ? 'ml-2' : 'mr-2'} />
                <span>{settings.language === 'ar' ? 'الرسائل' : 'Messages'}</span>
              </button>
            </li>
            <li>
              <button
                onClick={() => handleMenuClick('profile')}
                className="w-full p-2 hover:bg-gray-100 rounded flex items-center"
              >
                <UserIcon size={18} className={settings.language === 'ar' ? 'ml-2' : 'mr-2'} />
                <span>{settings.language === 'ar' ? 'الملف الشخصي' : 'Profile'}</span>
              </button>
            </li>
            <li>
              <button
                onClick={() => handleMenuClick('chart')}
                className="w-full p-2 hover:bg-gray-100 rounded flex items-center"
              >
                <ChartBar size={18} className={settings.language === 'ar' ? 'ml-2' : 'mr-2'} />
                <span>{settings.language === 'ar' ? 'التحليل' : 'Analysis'}</span>
              </button>
            </li>
            <li>
              <button
                onClick={() => handleMenuClick('settings')}
                className="w-full p-2 hover:bg-gray-100 rounded flex items-center"
              >
                <SettingsIcon size={18} className={settings.language === 'ar' ? 'ml-2' : 'mr-2'} />
                <span>{settings.language === 'ar' ? 'الإعدادات' : 'Settings'}</span>
              </button>
            </li>
            <li className="border-t mt-4 pt-4">
              <button
                onClick={handleLogout}
                className="w-full p-2 text-red-600 hover:bg-red-50 rounded flex items-center"
              >
                <LogOut size={18} className={settings.language === 'ar' ? 'ml-2' : 'mr-2'} />
                <span>{settings.language === 'ar' ? 'تسجيل الخروج' : 'Logout'}</span>
              </button>
            </li>
          </ul>
        </nav>
      </div>

      <main className="container mx-auto px-4" style={{ paddingTop: '120px', marginTop: '2rem' }}>
        {currentScreen === 'messages' && (
          <div className={`p-6 rounded-lg ${settings.darkMode ? 'bg-gray-800' : 'bg-white'} shadow-md mt-6`}>
            <h2 className={`text-2xl font-bold mb-4 ${settings.language === 'ar' ? 'text-right' : 'text-left'}`}>
              {settings.language === 'ar' ? 'الرسائل المستلمة' : 'Received Messages'}
            </h2>
            <div className="space-y-4">
              {notifications.map((message) => (
                <div 
                  key={message.id} 
                  className={`p-4 rounded-lg ${
                    message.read 
                      ? settings.darkMode ? 'bg-gray-700' : 'bg-gray-50'
                      : settings.darkMode ? 'bg-blue-900' : 'bg-blue-50'
                  }`}
                >
                  <p className="font-semibold">{message.spiritualMessage}</p>
                  <p className="mt-2">{message.notification}</p>
                  <p className="text-sm text-gray-500 mt-2">
                    {new Date(message.timestamp).toLocaleString(
                      settings.language === 'ar' ? 'ar-EG' : 'en-US'
                    )}
                  </p>
                </div>
              ))}
            </div>
          </div>
        )}
        {currentScreen === 'tasks' && (
          <div className="mt-6">
            <TaskGrid
              tasks={tasks}
              onTaskComplete={handleTaskComplete}
              language={settings.language}
              darkMode={settings.darkMode}
              coinAnimation={true}
            />
          </div>
        )}
        {currentScreen === 'profile' && authState.user && (
          <div className="mt-6">
            <Profile
              user={authState.user}
              onUpdate={handleProfileUpdate}
              language={settings.language}
              darkMode={settings.darkMode}
            />
          </div>
        )}
        {currentScreen === 'chart' && (
          <div className="mt-6">
            <DailyChart
              data={dailyData}
              language={settings.language}
              darkMode={settings.darkMode}
            />
          </div>
        )}
        {currentScreen === 'settings' && (
          <div className="mt-6">
            <Settings
              settings={settings}
              onUpdate={handleSettingsUpdate}
              onLogout={handleLogout}
              onSwitchUser={() => {
                handleLogout();
                setCurrentScreen('tasks');
              }}
              language={settings.language}
              darkMode={settings.darkMode}
            />
          </div>
        )}
      </main>
    </div>
  );
}

export default App;