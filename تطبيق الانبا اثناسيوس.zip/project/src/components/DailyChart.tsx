import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  ChartOptions
} from 'chart.js';
import { Line } from 'react-chartjs-2';
import { DailyAnalysis } from '../types';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

interface Props {
  data: DailyAnalysis[];
  language?: 'ar' | 'en';
  darkMode?: boolean;
}

export const DailyChart = ({ data, language = 'ar', darkMode = false }: Props) => {
  const today = new Date();
  const weeklyAverage = data.length > 0
    ? Math.round(data.reduce((acc, curr) => acc + curr.points, 0) / data.length)
    : 0;

  const chartData = {
    labels: data.map(d => {
      const date = new Date(d.date);
      return date.toLocaleDateString(language === 'ar' ? 'ar-EG' : 'en-US', {
        weekday: 'short',
        month: 'short',
        day: 'numeric'
      });
    }),
    datasets: [
      {
        label: language === 'ar' ? 'النقاط اليومية' : 'Daily Points',
        data: data.map(d => d.points),
        borderColor: darkMode ? 'rgb(147, 197, 253)' : 'rgb(59, 130, 246)',
        backgroundColor: darkMode ? 'rgba(147, 197, 253, 0.5)' : 'rgba(59, 130, 246, 0.5)',
        tension: 0.1
      }
    ]
  };

  const options: ChartOptions<'line'> = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'top',
        labels: {
          color: darkMode ? '#fff' : '#000'
        }
      },
      title: {
        display: true,
        text: language === 'ar' ? 'تحليل النقاط اليومية' : 'Daily Points Analysis',
        color: darkMode ? '#fff' : '#000'
      }
    },
    scales: {
      x: {
        type: 'category',
        ticks: {
          color: darkMode ? '#fff' : '#000'
        },
        grid: {
          color: darkMode ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.1)'
        }
      },
      y: {
        type: 'linear',
        beginAtZero: true,
        ticks: {
          color: darkMode ? '#fff' : '#000'
        },
        grid: {
          color: darkMode ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.1)'
        }
      }
    }
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className={`p-4 rounded-lg ${darkMode ? 'bg-gray-800' : 'bg-white'} shadow-md`}>
          <h3 className={`text-lg font-semibold mb-2 ${language === 'ar' ? 'text-right' : 'text-left'}`}>
            {language === 'ar' ? 'إحصائيات اليوم' : 'Today\'s Statistics'}
          </h3>
          <p className={`${language === 'ar' ? 'text-right' : 'text-left'}`}>
            {language === 'ar' ? 'التاريخ: ' : 'Date: '}
            {today.toLocaleDateString(language === 'ar' ? 'ar-EG' : 'en-US', {
              weekday: 'long',
              year: 'numeric',
              month: 'long',
              day: 'numeric'
            })}
          </p>
          <p className={`${language === 'ar' ? 'text-right' : 'text-left'}`}>
            {language === 'ar' ? 'النقاط: ' : 'Points: '}
            {data[data.length - 1]?.points || 0}
          </p>
        </div>
        
        <div className={`p-4 rounded-lg ${darkMode ? 'bg-gray-800' : 'bg-white'} shadow-md`}>
          <h3 className={`text-lg font-semibold mb-2 ${language === 'ar' ? 'text-right' : 'text-left'}`}>
            {language === 'ar' ? 'متوسط النقاط الأسبوعي' : 'Weekly Average'}
          </h3>
          <p className={`${language === 'ar' ? 'text-right' : 'text-left'}`}>
            {language === 'ar' ? 'المتوسط: ' : 'Average: '}
            {weeklyAverage}
            {language === 'ar' ? ' نقطة' : ' points'}
          </p>
        </div>
      </div>

      <div className={`w-full h-[400px] p-4 rounded-lg ${darkMode ? 'bg-gray-800' : 'bg-white'} shadow-md`}>
        <Line data={chartData} options={options} />
      </div>
    </div>
  );
};