import { useState, useRef } from 'react';
import { User } from '../types';
import { motion } from 'framer-motion';
import QRCode from 'qrcode.react';
import { 
  Camera, 
  User as UserIcon, 
  Mail, 
  Phone, 
  Building, 
  Calendar,
  Save,
  QrCode
} from 'lucide-react';

interface Props {
  user: User;
  onUpdate: (user: User) => void;
  language?: 'ar' | 'en';
  darkMode?: boolean;
}

export const Profile = ({ user, onUpdate, language = 'ar', darkMode = false }: Props) => {
  const [formData, setFormData] = useState(user);
  const [showQR, setShowQR] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Save to localStorage
    const users = JSON.parse(localStorage.getItem('users') || '{}');
    users[user.id] = {
      ...users[user.id],
      ...formData
    };
    localStorage.setItem('users', JSON.stringify(users));
    onUpdate(formData);
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData(prev => ({
          ...prev,
          profilePicture: reader.result as string
        }));
      };
      reader.readAsDataURL(file);
    }
  };

  const userDataForQR = {
    username: user.username,
    email: user.email,
    phone: user.phone,
    churchName: user.churchName,
    confessorName: user.confessorName,
    dateOfBirth: user.dateOfBirth
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className={`${darkMode ? 'bg-gray-800' : 'bg-white'} rounded-lg shadow-md p-6`}
    >
      <h2 className={`text-2xl font-bold mb-6 ${language === 'ar' ? 'text-right' : 'text-left'}`}>
        <UserIcon className={`inline ${language === 'ar' ? 'ml-2' : 'mr-2'}`} size={24} />
        {language === 'ar' ? 'الملف الشخصي' : 'Profile'}
      </h2>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="flex justify-center mb-6">
          <div className="relative">
            <img
              src={formData.profilePicture || 'https://via.placeholder.com/150'}
              alt="Profile"
              className="w-32 h-32 rounded-full object-cover"
            />
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="absolute bottom-0 right-0 bg-blue-600 text-white p-2 rounded-full hover:bg-blue-700"
            >
              <Camera size={20} />
            </button>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handleImageUpload}
              className="hidden"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className={`block mb-1 ${language === 'ar' ? 'text-right' : 'text-left'}`}>
              <UserIcon className={`inline ${language === 'ar' ? 'ml-2' : 'mr-2'}`} size={18} />
              {language === 'ar' ? 'اسم المستخدم' : 'Username'}
            </label>
            <input
              type="text"
              value={formData.username}
              onChange={(e) => setFormData({ ...formData, username: e.target.value })}
              className={`w-full p-3 border rounded-lg ${language === 'ar' ? 'text-right' : 'text-left'}`}
              dir={language === 'ar' ? 'rtl' : 'ltr'}
            />
          </div>

          <div>
            <label className={`block mb-1 ${language === 'ar' ? 'text-right' : 'text-left'}`}>
              <Mail className={`inline ${language === 'ar' ? 'ml-2' : 'mr-2'}`} size={18} />
              {language === 'ar' ? 'البريد الإلكتروني' : 'Email'}
            </label>
            <input
              type="email"
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              className={`w-full p-3 border rounded-lg ${language === 'ar' ? 'text-right' : 'text-left'}`}
              dir={language === 'ar' ? 'rtl' : 'ltr'}
            />
          </div>

          <div>
            <label className={`block mb-1 ${language === 'ar' ? 'text-right' : 'text-left'}`}>
              <Phone className={`inline ${language === 'ar' ? 'ml-2' : 'mr-2'}`} size={18} />
              {language === 'ar' ? 'رقم الهاتف' : 'Phone'}
            </label>
            <input
              type="tel"
              value={formData.phone}
              onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
              className={`w-full p-3 border rounded-lg ${language === 'ar' ? 'text-right' : 'text-left'}`}
              dir={language === 'ar' ? 'rtl' : 'ltr'}
            />
          </div>

          <div>
            <label className={`block mb-1 ${language === 'ar' ? 'text-right' : 'text-left'}`}>
              <Building className={`inline ${language === 'ar' ? 'ml-2' : 'mr-2'}`} size={18} />
              {language === 'ar' ? 'اسم الكنيسة' : 'Church Name'}
            </label>
            <input
              type="text"
              value={formData.churchName}
              onChange={(e) => setFormData({ ...formData, churchName: e.target.value })}
              className={`w-full p-3 border rounded-lg ${language === 'ar' ? 'text-right' : 'text-left'}`}
              dir={language === 'ar' ? 'rtl' : 'ltr'}
            />
          </div>

          <div>
            <label className={`block mb-1 ${language === 'ar' ? 'text-right' : 'text-left'}`}>
              <UserIcon className={`inline ${language === 'ar' ? 'ml-2' : 'mr-2'}`} size={18} />
              {language === 'ar' ? 'أب الاعتراف' : 'Confessor'}
            </label>
            <input
              type="text"
              value={formData.confessorName}
              onChange={(e) => setFormData({ ...formData, confessorName: e.target.value })}
              className={`w-full p-3 border rounded-lg ${language === 'ar' ? 'text-right' : 'text-left'}`}
              dir={language === 'ar' ? 'rtl' : 'ltr'}
            />
          </div>

          <div>
            <label className={`block mb-1 ${language === 'ar' ? 'text-right' : 'text-left'}`}>
              <Calendar className={`inline ${language === 'ar' ? 'ml-2' : 'mr-2'}`} size={18} />
              {language === 'ar' ? 'تاريخ الميلاد' : 'Date of Birth'}
            </label>
            <input
              type="date"
              value={formData.dateOfBirth}
              onChange={(e) => setFormData({ ...formData, dateOfBirth: e.target.value })}
              className="w-full p-3 border rounded-lg"
            />
          </div>
        </div>

        <div className="flex justify-between items-center mt-6">
          <button
            type="submit"
            className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 flex items-center"
          >
            <Save className={`${language === 'ar' ? 'ml-2' : 'mr-2'}`} size={18} />
            {language === 'ar' ? 'حفظ التغييرات' : 'Save Changes'}
          </button>
          
          <button
            type="button"
            onClick={() => setShowQR(!showQR)}
            className="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700 flex items-center"
          >
            <QrCode className={`${language === 'ar' ? 'ml-2' : 'mr-2'}`} size={18} />
            {language === 'ar' ? 'عرض QR' : 'Show QR'}
          </button>
        </div>
      </form>

      {showQR && (
        <div className="mt-6 flex justify-center">
          <QRCode
            value={JSON.stringify(userDataForQR)}
            size={200}
            level="H"
            includeMargin={true}
            className={darkMode ? 'bg-white p-2 rounded' : ''}
          />
        </div>
      )}
    </motion.div>
  );
};

export default Profile;