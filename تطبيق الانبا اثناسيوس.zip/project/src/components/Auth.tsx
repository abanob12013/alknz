import { useState, useEffect } from 'react';
import { motion, useAnimation } from 'framer-motion';
import { User } from '../types';
import { 
  Lock, 
  Square, 
  UserCircle, 
  Mail, 
  Building, 
  User as UserIcon, 
  Calendar, 
  Fingerprint,
  Chrome
} from 'lucide-react';

interface Props {
  onLogin: (user: User) => void;
  onAdminLogin: () => void;
  language?: 'ar' | 'en';
  useBiometrics?: boolean;
}

export const Auth = ({ onLogin, onAdminLogin, language = 'ar', useBiometrics = false }: Props) => {
  const [isLogin, setIsLogin] = useState(true);
  const [rememberMe, setRememberMe] = useState(false);
  const logoControls = useAnimation();
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [showBiometricAuth, setShowBiometricAuth] = useState(false);
  const [formData, setFormData] = useState({
    username: '',
    email: '',
    password: '',
    confirmPassword: '',
    phone: '',
    churchName: '',
    confessorName: '',
    dateOfBirth: '',
  });

  const handleGoogleSignIn = async () => {
    try {
      const mockGoogleData = {
        email: 'user@gmail.com',
        name: 'Google User',
        picture: 'https://source.unsplash.com/random/100x100'
      };

      const userId = Date.now().toString();
      const user: User = {
        id: userId,
        username: mockGoogleData.name,
        email: mockGoogleData.email,
        phone: '',
        churchName: '',
        confessorName: '',
        dateOfBirth: '',
        profilePicture: mockGoogleData.picture
      };

      const users = JSON.parse(localStorage.getItem('users') || '{}');
      users[userId] = {
        ...user,
        settings: {
          fontSize: 16,
          language: 'ar',
          useBiometrics: false,
          darkMode: false
        },
        points: 0,
        dailyData: [],
        notifications: []
      };
      localStorage.setItem('users', JSON.stringify(users));
      localStorage.setItem('lastLoggedInUser', userId);

      onLogin(user);
    } catch (error) {
      console.error('Google sign in failed:', error);
      alert(language === 'ar' ? 'فشل تسجيل الدخول بحساب جوجل' : 'Google sign in failed');
    }
  };

  useEffect(() => {
    const savedCredentials = localStorage.getItem('rememberedCredentials');
    if (savedCredentials) {
      const { username, password, timestamp } = JSON.parse(savedCredentials);
      const currentTime = new Date().getTime();
      const thirtyMinutes = 30 * 60 * 1000;
      
      if (currentTime - timestamp < thirtyMinutes) {
        setFormData(prev => ({ ...prev, username, password }));
        setRememberMe(true);
      } else {
        localStorage.removeItem('rememberedCredentials');
      }
    }
  }, []);

  useEffect(() => {
    let isMounted = true;
    let animationFrame: number;

    const animate = async () => {
      // Wait for next frame to ensure component is mounted
      animationFrame = requestAnimationFrame(async () => {
        if (!isMounted) return;

        try {
          while (isMounted) {
            await logoControls.start({
              y: -10,
              transition: { duration: 1, ease: "easeInOut" }
            });
            if (!isMounted) break;
            
            await logoControls.start({
              y: 10,
              transition: { duration: 1, ease: "easeInOut" }
            });
          }
        } catch (error) {
          if (isMounted && error instanceof Error) {
            console.error('Animation error:', error.message);
          }
        }
      });
    };

    // Start animation after a short delay
    const timeoutId = setTimeout(animate, 100);

    return () => {
      isMounted = false;
      clearTimeout(timeoutId);
      if (animationFrame) {
        cancelAnimationFrame(animationFrame);
      }
      logoControls.stop();
    };
  }, [logoControls]);

  const handleBiometricAuth = async () => {
    try {
      setShowBiometricAuth(true);
      
      if (!window.PublicKeyCredential) {
        alert(language === 'ar' 
          ? 'المتصفح لا يدعم المصادقة البيومترية' 
          : 'Browser does not support biometric authentication');
        setShowBiometricAuth(false);
        return;
      }

      const available = await PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable();
      if (!available) {
        alert(language === 'ar'
          ? 'المصادقة البيومترية غير متوفرة على هذا الجهاز'
          : 'Biometric authentication is not available on this device');
        setShowBiometricAuth(false);
        return;
      }

      // Simulate biometric authentication
      setTimeout(() => {
        const lastUser = localStorage.getItem('lastLoggedInUser');
        if (lastUser) {
          const users = JSON.parse(localStorage.getItem('users') || '{}');
          const user = users[lastUser];
          if (user) {
            if (user.blocked) {
              alert(language === 'ar' 
                ? 'هذا الحساب محظور. يرجى التواصل مع المسؤول.' 
                : 'This account is blocked. Please contact the administrator.');
              setShowBiometricAuth(false);
              return;
            }
            onLogin(user);
            return;
          }
        }
        
        alert(language === 'ar'
          ? 'فشلت المصادقة البيومترية'
          : 'Biometric authentication failed');
        setShowBiometricAuth(false);
      }, 2000);
      
    } catch (error) {
      console.error('Biometric authentication failed:', error);
      alert(language === 'ar'
        ? 'فشلت المصادقة البيومترية'
        : 'Biometric authentication failed');
      setShowBiometricAuth(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (formData.username === 'admin' && formData.password === 'admin') {
      onAdminLogin();
      return;
    }
    
    if (!isLogin && formData.password !== formData.confirmPassword) {
      alert(language === 'ar' ? 'كلمات المرور غير متطابقة' : 'Passwords do not match');
      return;
    }

    if (!isLogin) {
      const userId = Date.now().toString();
      const user: User = {
        id: userId,
        username: formData.username,
        email: formData.email,
        phone: formData.phone,
        churchName: formData.churchName,
        confessorName: formData.confessorName,
        dateOfBirth: formData.dateOfBirth,
      };

      const users = JSON.parse(localStorage.getItem('users') || '{}');
      users[userId] = {
        ...user,
        password: formData.password,
        settings: {
          fontSize: 16,
          language: 'ar',
          useBiometrics: false,
          darkMode: false
        },
        points: 0,
        dailyData: [],
        notifications: []
      };
      localStorage.setItem('users', JSON.stringify(users));
      localStorage.setItem('lastLoggedInUser', userId);
      
      if (rememberMe) {
        localStorage.setItem('rememberedCredentials', JSON.stringify({
          username: formData.username,
          password: formData.password,
          timestamp: new Date().getTime()
        }));
      }

      onLogin(user);
    } else {
      const users = JSON.parse(localStorage.getItem('users') || '{}');
      const user = Object.values(users).find((u: any) => 
        (u.username === formData.username || u.email === formData.username) && 
        u.password === formData.password
      );

      if (user) {
        // Check if user is blocked
        if ((user as any).blocked) {
          alert(language === 'ar' 
            ? 'هذا الحساب محظور. يرجى التواصل مع المسؤول.' 
            : 'This account is blocked. Please contact the administrator.');
          return;
        }
        
        localStorage.setItem('lastLoggedInUser', user.id);
        if (rememberMe) {
          localStorage.setItem('rememberedCredentials', JSON.stringify({
            username: formData.username,
            password: formData.password,
            timestamp: new Date().getTime()
          }));
        }
        onLogin(user as User);
      } else {
        alert(language === 'ar' ? 'اسم المستخدم أو كلمة المرور غير صحيحة' : 'Invalid username or password');
      }
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 flex items-center justify-center p-4" dir={language === 'ar' ? 'rtl' : 'ltr'}>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white rounded-lg shadow-xl p-6 w-full max-w-md"
      >
        <div className="text-center mb-8">
          <motion.img
            animate={logoControls}
            src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgKReMTpMeSY8QoSlsHDjN-xc4QIJivKD8V4oSZJD_QusU7AB9OSzqnlTKJdFhxGrmUAUh0MbKCW8FtM2pnY7FUDvmbE_urTCCnsgTj-4ovpK2nkWNuQWZtxsqwBJLztCFohiWiyTLr1Lha9Nf_8rQpp4yMjHQgawHKCWOt47Gpa-t56sdM6lqUUcbclBuz/s500/pngegg%20(2).png"
            alt="Logo"
            className="w-32 h-32 mx-auto mb-4"
          />
          <h2 className="text-2xl font-bold text-gray-800">
            {isLogin 
              ? (language === 'ar' ? 'تسجيل الدخول' : 'Login')
              : (language === 'ar' ? 'تسجيل جديد' : 'Register')}
          </h2>
        </div>

        <div className="mb-4">
          <button
            onClick={handleGoogleSignIn}
            className="w-full bg-white border border-gray-300 text-gray-800 px-6 py-3 rounded-lg hover:bg-gray-50 flex items-center justify-center"
          >
            <Chrome className={`${language === 'ar' ? 'ml-2' : 'mr-2'}`} size={24} />
            {language === 'ar' 
              ? (isLogin ? 'تسجيل الدخول بحساب جوجل' : 'التسجيل بحساب جوجل')
              : (isLogin ? 'Sign in with Google' : 'Sign up with Google')}
          </button>
        </div>

        <div className="relative mb-4 flex items-center">
          <div className="flex-grow border-t border-gray-300"></div>
          <span className="flex-shrink mx-4 text-gray-600">
            {language === 'ar' ? 'أو' : 'OR'}
          </span>
          <div className="flex-grow border-t border-gray-300"></div>
        </div>

        {useBiometrics && isLogin && (
          <div className="mb-4 text-center">
            <button
              onClick={handleBiometricAuth}
              className="bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 flex items-center justify-center w-full"
              disabled={showBiometricAuth}
            >
              <Fingerprint className={`${language === 'ar' ? 'ml-2' : 'mr-2'}`} size={24} />
              {language === 'ar' ? 'تسجيل الدخول بالبصمة' : 'Login with Biometrics'}
            </button>
            
            {showBiometricAuth && (
              <div className="mt-4 p-4 border border-green-300 rounded-lg bg-green-50">
                <div className="animate-pulse flex flex-col items-center">
                  <Fingerprint size={48} className="text-green-500 mb-2" />
                  <p className="text-green-700">
                    {language === 'ar' ? 'يرجى استخدام البصمة للمصادقة...' : 'Please use fingerprint to authenticate...'}
                  </p>
                </div>
              </div>
            )}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <UserCircle className="h-5 w-5 text-gray-400" />
            </div>
            <input
              type="text"
              placeholder={language === 'ar' ? 'اسم المستخدم أو البريد الإلكتروني' : 'Username or Email'}
              value={formData.username}
              onChange={(e) => setFormData({ ...formData, username: e.target.value })}
              className="w-full pl-10 pr-3 py-3 border rounded-lg focus:ring-2 focus:ring-blue-500"
              required
            />
          </div>

          {!isLogin && (
            <>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Mail className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  type="email"
                  placeholder={language === 'ar' ? 'البريد الإلكتروني' : 'Email'}
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="w-full pl-10 pr-3 py-3 border rounded-lg focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <UserIcon className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  type="tel"
                  placeholder={language === 'ar' ? 'رقم الهاتف' : 'Phone'}
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className="w-full pl-10 pr-3 py-3 border rounded-lg focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Building className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  type="text"
                  placeholder={language === 'ar' ? 'اسم الكنيسة' : 'Church Name'}
                  value={formData.churchName}
                  onChange={(e) => setFormData({ ...formData, churchName: e.target.value })}
                  className="w-full pl-10 pr-3 py-3 border rounded-lg focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <UserIcon className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  type="text"
                  placeholder={language === 'ar' ? 'أب الاعتراف' : 'Confessor'}
                  value={formData.confessorName}
                  onChange={(e) => setFormData({ ...formData, confessorName: e.target.value })}
                  className="w-full pl-10 pr-3 py-3 border rounded-lg focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Calendar className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  type="date"
                  value={formData.dateOfBirth}
                  onChange={(e) => setFormData({ ...formData, dateOfBirth: e.target.value })}
                  className="w-full pl-10 pr-3 py-3 border rounded-lg focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>
            </>
          )}

          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Lock className="h-5 w-5 text-gray-400" />
            </div>
            <input
              type={showPassword ? "text" : "password"}
              placeholder={language === 'ar' ? 'كلمة المرور' : 'Password'}
              value={formData.password}
              onChange={(e) => setFormData({ ...formData, password: e.target.value })}
              className="w-full pl-10 pr-10 py-3 border rounded-lg focus:ring-2 focus:ring-blue-500"
              required
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute top-3 right-3"
            >
              <Square size={20} className={showPassword ? 'text-blue-500' : 'text-gray-400'} />
            </button>
          </div>

          {!isLogin && (
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Lock className="h-5 w-5 text-gray-400" />
              </div>
              <input
                type={showConfirmPassword ? "text" : "password"}
                placeholder={language === 'ar' ? 'تأكيد كلمة المرور' : 'Confirm Password'}
                value={formData.confirmPassword}
                onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                className="w-full pl-10 pr-10 py-3 border rounded-lg focus:ring-2 focus:ring-blue-500"
                required
              />
              <button
                type="button"
                onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                className="absolute top-3 right-3"
              >
                <Square size={20} className={showConfirmPassword ? 'text-blue-500' : 'text-gray-400'} />
              </button>
            </div>
          )}

          <div className="flex items-center space-x-2">
            <input
              type="checkbox"
              id="rememberMe"
              checked={rememberMe}
              onChange={(e) => setRememberMe(e.target.checked)}
              className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
            />
            <label htmlFor="rememberMe" className="text-sm text-gray-600">
              {language === 'ar' ? 'تذكرني' : 'Remember me'}
            </label>
          </div>

          <button
            type="submit"
            className="w-full bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 transition duration-200"
            disabled={showBiometricAuth}
          >
            {isLogin 
              ? (language === 'ar' ? 'دخول' : 'Login')
              : (language === 'ar' ? 'تسجيل' : 'Register')}
          </button>
        </form>

        <div className="mt-4 text-center">
          <button
            onClick={() => setIsLogin(!isLogin)}
            className="text-blue-600 hover:underline"
            disabled={showBiometricAuth}
          >
            {isLogin 
              ? (language === 'ar' ? 'تسجيل حساب جديد' : 'Create new account')
              : (language === 'ar' ? 'لدي حساب بالفعل' : 'I already have an account')}
          </button>
        </div>
      </motion.div>
    </div>
  );
};