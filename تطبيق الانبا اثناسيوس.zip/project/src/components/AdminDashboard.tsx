import { useState, useEffect } from 'react';
import { Line } from 'react-chartjs-2';
import { format } from 'date-fns';
import { arEG, enUS } from 'date-fns/locale';
import { User, DailyAnalysis, Message, Settings } from '../types';
import { 
  Menu, 
  Info, 
  FileText, 
  Mail, 
  Home, 
  User as UserIcon, 
  BarChart as ChartBar, 
  Settings as SettingsIcon,
  MessageSquare,
  Bell,
  Trash2,
  Coins,
  LogOut,
  Clock,
  Camera,
  Moon,
  Sun,
  Languages,
  Fingerprint
} from 'lucide-react';

interface Props {
  onLogout: () => void;
  language?: 'ar' | 'en';
}

const translations = {
  ar: {
    dashboard: 'لوحة التحكم',
    users: 'المستخدمين',
    messages: 'الرسائل',
    settings: 'الإعدادات',
    logout: 'تسجيل الخروج',
    todayStats: 'إحصائيات اليوم',
    date: 'التاريخ',
    totalPoints: 'مجموع النقاط',
    weeklyAverage: 'متوسط النقاط الأسبوعي',
    average: 'المتوسط',
    points: 'نقطة',
    dailyAnalysis: 'تحليل النقاط اليومية',
    completedTasks: 'المهام المنفذة',
    username: 'اسم المستخدم',
    task: 'المهمة',
    points2: 'النقاط',
    date2: 'التاريخ',
    userData: 'بيانات المستخدمين',
    deleteSelected: 'حذف المحدد',
    email: 'البريد الإلكتروني',
    phone: 'رقم الهاتف',
    church: 'اسم الكنيسة',
    birthDate: 'تاريخ الميلاد',
    sentMessages: 'الرسائل المرسلة',
    spiritualMessage: 'رسالة روحية...',
    notification: 'إشعار...',
    send: 'إرسال',
    messageSent: 'تم إرسال الرسالة بنجاح',
    appearance: 'المظهر',
    darkMode: 'الوضع الليلي',
    lightMode: 'الوضع النهاري',
    language: 'اللغة',
    biometrics: 'البصمة',
    enableBiometrics: 'تفعيل البصمة',
    disableBiometrics: 'تعطيل البصمة',
    dateAndTime: 'الوقت والتاريخ',
    userAnalytics: 'تحليل المستخدمين',
    attendanceAbsence: 'الاعتراف والافتقاد',
    confession: 'الاعتراف',
    absence: 'الافتقاد',
    statistics: 'الإحصائيات',
    scanQR: 'مسح QR',
    enterQRData: 'أدخل البيانات بصيغة: اسم المستخدم,رقم الهاتف,البريد الإلكتروني,تاريخ الميلاد',
    invalidQRData: 'الرجاء إدخال البيانات بشكل صحيح',
    delete: 'حذف',
    back: 'رجوع',
    fpAuth: 'مصادقة البصمة',
    openCamera: 'فتح الكاميرا',
    scanningQR: 'جاري مسح رمز QR...',
    closeCamera: 'إغلاق الكاميرا',
    analytics: 'تحليل البيانات',
    viewAnalytics: 'عرض التحليل',
    block: 'حظر',
    unblock: 'إلغاء الحظر',
    lastConfession: 'آخر اعتراف',
    lastVisit: 'آخر افتقاد',
    sendMessage: 'إرسال رسالة',
    messageContent: 'محتوى الرسالة',
    sendToAll: 'إرسال للجميع',
    sendToSelected: 'إرسال للمحددين',
    selectUsers: 'اختر المستخدمين',
    noUsersSelected: 'لم يتم اختيار مستخدمين',
    messageRequired: 'الرجاء إدخال محتوى الرسالة',
    confirmDelete: 'هل أنت متأكد من حذف هذا المستخدم؟',
    yes: 'نعم',
    no: 'لا',
    userBlocked: 'تم حظر المستخدم',
    userUnblocked: 'تم إلغاء حظر المستخدم',
    confirmBlock: 'هل أنت متأكد من حظر هذا المستخدم؟',
    confirmUnblock: 'هل أنت متأكد من إلغاء حظر هذا المستخدم؟',
    search: 'بحث...',
    filterByDate: 'تصفية حسب التاريخ',
    from: 'من',
    to: 'إلى',
    apply: 'تطبيق',
    reset: 'إعادة تعيين',
    export: 'تصدير',
    print: 'طباعة',
    total: 'المجموع',
    average: 'المتوسط',
    highest: 'الأعلى',
    lowest: 'الأدنى',
    noData: 'لا توجد بيانات',
    loading: 'جاري التحميل...',
    error: 'حدث خطأ',
    retry: 'إعادة المحاولة',
    settings: 'الإعدادات',
    profile: 'الملف الشخصي',
    notifications: 'الإشعارات',
    help: 'المساعدة',
    about: 'حول',
    version: 'الإصدار',
    copyright: 'جميع الحقوق محفوظة',
    terms: 'الشروط والأحكام',
    privacy: 'سياسة الخصوصية',
    contact: 'اتصل بنا',
    feedback: 'إرسال ملاحظات',
    reportIssue: 'الإبلاغ عن مشكلة',
    update: 'تحديث',
    newVersion: 'إصدار جديد متاح',
    install: 'تثبيت',
    later: 'لاحقاً',
    welcome: 'مرحباً',
    lastLogin: 'آخر تسجيل دخول',
    loginTime: 'وقت تسجيل الدخول',
    ipAddress: 'عنوان IP',
    browser: 'المتصفح',
    os: 'نظام التشغيل',
    device: 'الجهاز',
    location: 'الموقع',
    status: 'الحالة',
    role: 'الدور',
    permissions: 'الصلاحيات',
    active: 'نشط',
    inactive: 'غير نشط',
    online: 'متصل',
    offline: 'غير متصل',
    away: 'غائب',
    busy: 'مشغول',
    lastSeen: 'آخر ظهور',
    activity: 'النشاط',
    recentActivity: 'النشاط الأخير',
    noActivity: 'لا يوجد نشاط',
    viewAll: 'عرض الكل',
    hide: 'إخفاء',
    show: 'إظهار',
    edit: 'تعديل',
    save: 'حفظ',
    cancel: 'إلغاء',
    confirm: 'تأكيد',
    success: 'تم بنجاح',
    warning: 'تحذير',
    info: 'معلومات',
    error: 'خطأ',
    close: 'إغلاق'
  },
  en: {
    dashboard: 'Dashboard',
    users: 'Users',
    messages: 'Messages',
    settings: 'Settings',
    logout: 'Logout',
    todayStats: "Today's Statistics",
    date: 'Date',
    totalPoints: 'Total Points',
    weeklyAverage: 'Weekly Average',
    average: 'Average',
    points: 'points',
    dailyAnalysis: 'Daily Points Analysis',
    completedTasks: 'Completed Tasks',
    username: 'Username',
    task: 'Task',
    points2: 'Points',
    date2: 'Date',
    userData: 'User Data',
    deleteSelected: 'Delete Selected',
    email: 'Email',
    phone: 'Phone',
    church: 'Church',
    birthDate: 'Birth Date',
    sentMessages: 'Sent Messages',
    spiritualMessage: 'Spiritual message...',
    notification: 'Notification...',
    send: 'Send',
    messageSent: 'Message sent successfully',
    appearance: 'Appearance',
    darkMode: 'Dark Mode',
    lightMode: 'Light Mode',
    language: 'Language',
    biometrics: 'Biometrics',
    enableBiometrics: 'Enable Biometrics',
    disableBiometrics: 'Disable Biometrics',
    dateAndTime: 'Date & Time',
    userAnalytics: 'User Analytics',
    attendanceAbsence: 'Confession & Visitation',
    confession: 'Confession',
    absence: 'Visitation',
    statistics: 'Statistics',
    scanQR: 'Scan QR',
    enterQRData: 'Enter data as: username,phone,email,birthDate',
    invalidQRData: 'Please enter data correctly',
    delete: 'Delete',
    back: 'Back',
    fpAuth: 'Fingerprint Authentication',
    openCamera: 'Open Camera',
    scanningQR: 'Scanning QR code...',
    closeCamera: 'Close Camera',
    analytics: 'Analytics',
    viewAnalytics: 'View Analytics',
    block: 'Block',
    unblock: 'Unblock',
    lastConfession: 'Last Confession',
    lastVisit: 'Last Visit',
    sendMessage: 'Send Message',
    messageContent: 'Message Content',
    sendToAll: 'Send to All',
    sendToSelected: 'Send to Selected',
    selectUsers: 'Select Users',
    noUsersSelected: 'No users selected',
    messageRequired: 'Please enter a message',
    confirmDelete: 'Are you sure you want to delete this user?',
    yes: 'Yes',
    no: 'No',
    userBlocked: 'User blocked',
    userUnblocked: 'User unblocked',
    confirmBlock: 'Are you sure you want to block this user?',
    confirmUnblock: 'Are you sure you want to unblock this user?',
    search: 'Search...',
    filterByDate: 'Filter by Date',
    from: 'From',
    to: 'To',
    apply: 'Apply',
    reset: 'Reset',
    export: 'Export',
    print: 'Print',
    total: 'Total',
    average: 'Average',
    highest: 'Highest',
    lowest: 'Lowest',
    noData: 'No data available',
    loading: 'Loading...',
    error: 'Error occurred',
    retry: 'Retry',
    settings: 'Settings',
    profile: 'Profile',
    notifications: 'Notifications',
    help: 'Help',
    about: 'About',
    version: 'Version',
    copyright: 'All rights reserved',
    terms: 'Terms & Conditions',
    privacy: 'Privacy Policy',
    contact: 'Contact Us',
    feedback: 'Send Feedback',
    reportIssue: 'Report Issue',
    update: 'Update',
    newVersion: 'New version available',
    install: 'Install',
    later: 'Later',
    welcome: 'Welcome',
    lastLogin: 'Last Login',
    loginTime: 'Login Time',
    ipAddress: 'IP Address',
    browser: 'Browser',
    os: 'OS',
    device: 'Device',
    location: 'Location',
    status: 'Status',
    role: 'Role',
    permissions: 'Permissions',
    active: 'Active',
    inactive: 'Inactive',
    online: 'Online',
    offline: 'Offline',
    away: 'Away',
    busy: 'Busy',
    lastSeen: 'Last Seen',
    activity: 'Activity',
    recentActivity: 'Recent Activity',
    noActivity: 'No activity',
    viewAll: 'View All',
    hide: 'Hide',
    show: 'Show',
    edit: 'Edit',
    save: 'Save',
    cancel: 'Cancel',
    confirm: 'Confirm',
    success: 'Success',
    warning: 'Warning',
    info: 'Info',
    error: 'Error',
    close: 'Close'
  }
};

// Task points array
const taskPoints = [1, 1, 1, 1, 1, 1, 1, 5, 10, 3, 7, 2, 1, 6, 8, 5, 2];

export const AdminDashboard = ({ onLogout, language = 'ar' }: Props) => {
  const [currentScreen, setCurrentScreen] = useState<'dashboard' | 'users' | 'settings' | 'messages' | 'confession' | 'visitation' | 'analytics'>('dashboard');
  const [menuOpen, setMenuOpen] = useState(false);
  const [showMessageForm, setShowMessageForm] = useState(false);
  const [messageData, setMessageData] = useState({
    spiritualMessage: '',
    notification: ''
  });
  const [messages, setMessages] = useState<Message[]>([]);
  const [settings, setSettings] = useState<Settings>({
    fontSize: 16,
    language,
    useBiometrics: false,
    darkMode: false
  });
  const [users, setUsers] = useState<User[]>([]);
  const [selectedUserId, setSelectedUserId] = useState<string | null>(null);
  const [showCamera, setShowCamera] = useState(false);
  const [confessionData, setConfessionData] = useState<any[]>([]);
  const [visitationData, setVisitationData] = useState<any[]>([]);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [dateFilter, setDateFilter] = useState({ from: '', to: '' });
  const [selectedUsers, setSelectedUsers] = useState<string[]>([]);
  const [showConfirmDialog, setShowConfirmDialog] = useState(false);
  const [confirmAction, setConfirmAction] = useState<() => void>(() => {});
  const [confirmMessage, setConfirmMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    setSettings(prev => ({ ...prev, language }));
  }, [language]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      const target = event.target as HTMLElement;
      if (!target.closest('.menu-button') && !target.closest('.menu-content')) {
        setMenuOpen(false);
      }
      if (!target.closest('.message-button') && !target.closest('.message-form')) {
        setShowMessageForm(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  useEffect(() => {
    loadUserData();
  }, []);

  const loadUserData = () => {
    try {
      setLoading(true);
      setError(null);
      const storedUsers = JSON.parse(localStorage.getItem('users') || '{}');
      const usersList = Object.values(storedUsers) as User[];
      setUsers(usersList);

      const storedMessages = JSON.parse(localStorage.getItem('admin_messages') || '[]');
      setMessages(storedMessages);
    } catch (error) {
      setError(error instanceof Error ? error.message : 'Failed to load user data');
    } finally {
      setLoading(false);
    }
  };

  const handleSendMessage = () => {
    if (!messageData.spiritualMessage.trim()) {
      alert(translations[language].messageRequired);
      return;
    }

    const newMessage: Message = {
      id: Date.now().toString(),
      spiritualMessage: messageData.spiritualMessage,
      notification: messageData.notification,
      timestamp: new Date().toISOString(),
      read: false
    };

    try {
      const updatedMessages = [...messages, newMessage];
      setMessages(updatedMessages);
      localStorage.setItem('admin_messages', JSON.stringify(updatedMessages));

      const users = JSON.parse(localStorage.getItem('users') || '{}');
      
      // If there are selected users, only send to them
      const targetUsers = selectedUsers.length > 0 
        ? selectedUsers 
        : Object.keys(users);

      targetUsers.forEach(userId => {
        if (users[userId]) {
          users[userId].notifications = users[userId].notifications || [];
          users[userId].notifications.push(newMessage);
        }
      });

      localStorage.setItem('users', JSON.stringify(users));
      setMessageData({ spiritualMessage: '', notification: '' });
      setShowMessageForm(false);
      setSelectedUsers([]);
      
      alert(translations[language].messageSent);
    } catch (error) {
      setError(error instanceof Error ? error.message : 'Failed to send message');
    }
  };

  const handleDeleteMessage = (messageId: string) => {
    try {
      const updatedMessages = messages.filter(msg => msg.id !== messageId);
      setMessages(updatedMessages);
      localStorage.setItem('admin_messages', JSON.stringify(updatedMessages));

      const users = JSON.parse(localStorage.getItem('users') || '{}');
      Object.keys(users).forEach(userId => {
        const user = users[userId];
        if (user.notifications) {
          user.notifications = user.notifications.filter((n: Message) => n.id !== messageId);
        }
      });
      localStorage.setItem('users', JSON.stringify(users));
    } catch (error) {
      setError(error instanceof Error ? error.message : 'Failed to delete message');
    }
  };

  const handleDeleteUser = (userId: string) => {
    setConfirmMessage(translations[language].confirmDelete);
    setConfirmAction(() => () => {
      try {
        const usersData = JSON.parse(localStorage.getItem('users') || '{}');
        delete usersData[userId];
        localStorage.setItem('users', JSON.stringify(usersData));
        setUsers(Object.values(usersData));
        setShowConfirmDialog(false);
      } catch (error) {
        setError(error instanceof Error ? error.message : 'Failed to delete user');
      }
    });
    setShowConfirmDialog(true);
  };

  const handleBlockUser = (userId: string) => {
    const usersData = JSON.parse(localStorage.getItem('users') || '{}');
    const isBlocked = usersData[userId]?.blocked;
    
    setConfirmMessage(isBlocked 
      ? translations[language].confirmUnblock 
      : translations[language].confirmBlock
    );
    
    setConfirmAction(() => () => {
      try {
        if (usersData[userId]) {
          usersData[userId].blocked = !isBlocked;
          localStorage.setItem('users', JSON.stringify(usersData));
          setUsers(Object.values(usersData));
          alert(isBlocked 
            ? translations[language].userUnblocked 
            : translations[language].userBlocked
          );
        }
        setShowConfirmDialog(false);
      } catch (error) {
        setError(error instanceof Error ? error.message : 'Failed to update user status');
      }
    });
    
    setShowConfirmDialog(true);
  };

  const handleViewAnalytics = (userId: string) => {
    setSelectedUserId(userId);
    setCurrentScreen('analytics');
  };

  const startCamera = async () => {
    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({ 
        video: { facingMode: 'environment' }
      });
      setStream(mediaStream);
      setShowCamera(true);

      // Here you would typically initialize a QR code scanner library
      // For this example, we'll simulate QR scanning with a timeout
      setTimeout(() => {
        const mockQRData = {
          username: "Test User",
          phone: "1234567890",
          email: "test@example.com",
          birthDate: "2000-01-01"
        };
        handleQRScan(mockQRData);
      }, 3000);
    } catch (error) {
      console.error('Error accessing camera:', error);
      alert(language === 'ar' 
        ? 'فشل في الوصول إلى الكاميرا' 
        : 'Failed to access camera');
    }
  };

  const stopCamera = () => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setStream(null);
    }
    setShowCamera(false);
  };

  const handleQRScan = (data: any) => {
    const newData = {
      ...data,
      scanDate: new Date().toISOString()
    };

    if (currentScreen === 'confession') {
      setConfessionData(prev => [...prev, newData]);
      updateUserConfessionDate(data.email);
    } else if (currentScreen === 'visitation') {
      setVisitationData(prev => [...prev, newData]);
      updateUserVisitationDate(data.email);
    }

    stopCamera();
  };

  const updateUserConfessionDate = (email: string) => {
    try {
      const usersData = JSON.parse(localStorage.getItem('users') || '{}');
      Object.keys(usersData).forEach(userId => {
        if (usersData[userId].email === email) {
          usersData[userId].lastConfessionDate = new Date().toISOString();
        }
      });
      localStorage.setItem('users', JSON.stringify(usersData));
      loadUserData();
    } catch (error) {
      setError(error instanceof Error ? error.message : 'Failed to update confession date');
    }
  };

  const updateUserVisitationDate = (email: string) => {
    try {
      const usersData = JSON.parse(localStorage.getItem('users') || '{}');
      Object.keys(usersData).forEach(userId => {
        if (usersData[userId].email === email) {
          usersData[userId].lastVisitationDate = new Date().toISOString();
        }
      });
      localStorage.setItem('users', JSON.stringify(usersData));
      loadUserData();
    } catch (error) {
      setError(error instanceof Error ? error.message : 'Failed to update visitation date');
    }
  };

  const handleSearch = (event: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(event.target.value);
  };

  const handleDateFilterChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = event.target;
    setDateFilter(prev => ({ ...prev, [name]: value }));
  };

  const handleUserSelection = (userId: string) => {
    setSelectedUsers(prev => 
      prev.includes(userId)
        ? prev.filter(id => id !== userId)
        : [...prev, userId]
    );
  };

  const filteredUsers = users.filter(user => {
    const searchMatch = 
      user.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.phone.includes(searchTerm);

    if (!dateFilter.from && !dateFilter.to) return searchMatch;

    const userDate = user.lastConfessionDate || user.lastVisitationDate;
    if (!userDate) return false;

    const date = new Date(userDate);
    const from = dateFilter.from ? new Date(dateFilter.from) : null;
    const to = dateFilter.to ? new Date(dateFilter.to) : null;

    return searchMatch && 
      (!from || date >= from) && 
      (!to || date <= to);
  });

  const renderUserAnalytics = () => {
    if (!selectedUserId) return null;

    const user = users.find(u => u.id === selectedUserId);
    if (!user) return null;

    const userData = user.dailyData || [];
    const chartData = {
      labels: userData.map(d => new Date(d.date).toLocaleDateString(language === 'ar' ? 'ar-EG' : 'en-US')),
      datasets: [{
        label: translations[language].points,
        data: userData.map(d => d.points),
        borderColor: settings.darkMode ? 'rgb(147, 197, 253)' : 'rgb(59, 130, 246)',
        backgroundColor: settings.darkMode ? 'rgba(147, 197, 253, 0.5)' : 'rgba(59, 130, 246, 0.5)',
      }]
    };

    const options = {
      responsive: true,
      maintainAspectRatio: false,
      scales: {
        y: {
          beginAtZero: true,
          ticks: {
            stepSize: 1
          }
        }
      },
      plugins: {
        legend: {
          display: false
        }
      }
    };

    const stats = {
      total: userData.reduce((sum, d) => sum + d.points, 0),
      average: userData.length 
        ? Math.round(userData.reduce((sum, d) => sum + d.points, 0) / userData.length) 
        : 0,
      highest: userData.length 
        ? Math.max(...userData.map(d => d.points)) 
        : 0,
      lowest: userData.length 
        ? Math.min(...userData.map(d => d.points)) 
        : 0
    };

    return (
      <div className={`p-4 rounded-lg ${settings.darkMode ? 'bg-gray-800' : 'bg-white'} shadow-md`}>
        <div className="mb-6 grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className={`p-4 rounded-lg ${settings.darkMode ? 'bg-gray-700' : 'bg-gray-100'}`}>
            <h3 className="text-sm font-medium">{translations[language].total}</h3>
            <p className="text-2xl font-bold">{stats.total}</p>
          </div>
          <div className={`p-4 rounded-lg ${settings.darkMode ? 'bg-gray-700' : 'bg-gray-100'}`}>
            <h3 className="text-sm font-medium">{translations[language].average}</h3>
            <p className="text-2xl font-bold">{stats.average}</p>
          </div>
          <div className={`p-4 rounded-lg ${settings.darkMode ? 'bg-gray-700' : 'bg-gray-100'}`}>
            <h3 className="text-sm font-medium">{translations[language].highest}</h3>
            <p className="text-2xl font-bold">{stats.highest}</p>
          </div>
          <div className={`p-4 rounded-lg ${settings.darkMode ? 'bg-gray-700' : 'bg-gray-100'}`}>
            <h3 className="text-sm font-medium">{translations[language].lowest}</h3>
            <p className="text-2xl font-bold">{stats.lowest}</p>
          </div>
        </div>

        <div className="h-[400px] mb-6">
          <Line data={chartData} options={options} />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className={`p-4 rounded-lg ${settings.darkMode ? 'bg-gray-700' : 'bg-gray-100'}`}>
            <p className="font-bold">{translations[language].lastConfession}</p>
            <p>{user.lastConfessionDate ? new Date(user.lastConfessionDate).toLocaleDateString(
              language === 'ar' ? 'ar-EG' : 'en-US'
            ) : '-'}</p>
          </div>
          <div className={`p-4 rounded-lg ${settings.darkMode ? 'bg-gray-700' : 'bg-gray-100'}`}>
            <p className="font-bold">{translations[language].lastVisit}</p>
            <p>{user.lastVisitationDate ? new Date(user.lastVisitationDate).toLocaleDateString(
              language === 'ar' ? 'ar-EG' : 'en-US'
            ) : '-'}</p>
          </div>
        </div>

        <div className="mt-6">
          <button
            onClick={() => setCurrentScreen('users')}
            className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
          >
            {translations[language].back}
          </button>
        </div>
      </div>
    );
  };

  return (
    <div className={`min-h-screen ${settings.darkMode ? 'bg-gray-900 text-white' : 'bg-gray-100'}`} dir={language === 'ar' ? 'rtl' : 'ltr'}>
      <header className={`${settings.darkMode ? 'bg-gray-800' : 'bg-white'} shadow-md p-4 fixed w-full top-0 z-40`}>
        <div className="container mx-auto flex items-center justify-between">
          <div className="flex-1">
            <button
              onClick={() => setMenuOpen(!menuOpen)}
              className="menu-button p-2 hover:bg-gray-100 rounded-full"
            >
              <Menu size={24} />
            </button>
          </div>
          <div className="flex-1 flex justify-center">
            <h1 className="text-2xl font-bold">
              {translations[language][currentScreen]}
            </h1>
          </div>
          <div className="flex-1 flex justify-end relative">
            <button
              onClick={() => setShowMessageForm(!showMessageForm)}
              className="message-button p-2 hover:bg-gray-100 rounded-full"
            >
              <MessageSquare size={24} />
            </button>
          </div>
        </div>
      </header>

      {menuOpen && (
        <nav className="menu-content fixed left-0 top-16 h-full w-64 z-50">
          <div className={`${settings.darkMode ? 'bg-gray-800' : 'bg-white'} shadow-lg p-4 h-full`}>
            <ul className="space-y-2">
              <li>
                <button
                  onClick={() => {
                    setCurrentScreen('dashboard');
                    setMenuOpen(false);
                  }}
                  className="w-full p-2 hover:bg-gray-100 rounded flex items-center"
                >
                  <Home size={18} className={language === 'ar' ? 'ml-2' : 'mr-2'} />
                  <span>{translations[language].dashboard}</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() => {
                    setCurrentScreen('users');
                    setMenuOpen(false);
                  }}
                  className="w-full p-2 hover:bg-gray-100 rounded flex items-center"
                >
                  <UserIcon size={18} className={language === 'ar' ? 'ml-2' : 'mr-2'} />
                  <span>{translations[language].users}</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() => {
                    setCurrentScreen('confession');
                    setMenuOpen(false);
                  }}
                  className="w-full p-2 hover:bg-gray-100 rounded flex items-center"
                >
                  <Clock size={18} className={language === 'ar' ? 'ml-2' : 'mr-2'} />
                  <span>{translations[language].confession}</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() => {
                    setCurrentScreen('visitation');
                    setMenuOpen(false);
                  }}
                  className="w-full p-2 hover:bg-gray-100 rounded flex items-center"
                >
                  <Clock size={18} className={language === 'ar' ? 'ml-2' : 'mr-2'} />
                  <span>{translations[language].absence}</span>
                </button>
              </li>
              <li className="border-t mt-4 pt-4">
                <button
                  onClick={onLogout}
                  className="w-full p-2 text-red-600 hover:bg-red-50 rounded flex items-center"
                >
                  <LogOut size={18} className={language === 'ar' ? 'ml-2' : 'mr-2'} />
                  <span>{translations[language].logout}</span>
                </button>
              </li>
            </ul>
          </div>
        </nav>
      )}

      {showMessageForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className={`message-form ${settings.darkMode ? 'bg-gray-800' : 'bg-white'} rounded-lg p-6 w-full max-w-lg mx-4`}>
            <h2 className="text-xl font-bold mb-4">
              {translations[language].sendMessage}
            </h2>
            <div className="space-y-4">
              <div>
                <label className="block mb-1">{translations[language].spiritualMessage}</label>
                <textarea
                  value={messageData.spiritualMessage}
                  onChange={(e) => setMessageData(prev => ({ ...prev, spiritualMessage: e.target.value }))}
                  className="w-full p-2 border rounded"
                  rows={4}
                />
              </div>
              <div>
                <label className="block mb-1">{translations[language].notification}</label>
                <textarea
                  value={messageData.notification}
                  onChange={(e) => setMessageData(prev => ({ ...prev, notification: e.target.value }))}
                  className="w-full p-2 border rounded"
                  rows={2}
                />
              </div>
              <div>
                <label className="block mb-1">{translations[language].selectUsers}</label>
                <div className="max-h-40 overflow-y-auto border rounded p-2">
                  {users.map(user => (
                    <div key={user.id} className="flex items-center p-1">
                      <input
                        type="checkbox"
                        checked={selectedUsers.includes(user.id)}
                        onChange={() => handleUserSelection(user.id)}
                        className="mr-2"
                      />
                      <span>{user.username}</span>
                    </div>
                  ))}
                </div>
              </div>
              <div className="flex justify-end space-x-2">
                <button
                  onClick={() => setShowMessageForm(false)}
                  className="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded"
                >
                  {translations[language].cancel}
                </button>
                <button
                  onClick={handleSendMessage}
                  className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
                >
                  {translations[language].send}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {showConfirmDialog && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className={`${settings.darkMode ? 'bg-gray-800' : 'bg-white'} rounded-lg p-6 w-full max-w-sm mx-4`}>
            <p className="text-lg mb-4">{confirmMessage}</p>
            <div className="flex justify-end space-x-2">
              <button
                onClick={() => setShowConfirmDialog(false)}
                className="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded"
              >
                {translations[language].no}
              </button>
              <button
                onClick={() => confirmAction()}
                className="px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700"
              >
                {translations[language].yes}
              </button>
            </div>
          </div>
        </div>
      )}

      <main className="container mx-auto p-4" style={{ paddingTop: '80px' }}>
        {error && (
          <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4">
            <span className="block sm:inline">{error}</span>
            <button
              className="absolute top-0 bottom-0 right-0 px-4 py-3"
              onClick={() => setError(null)}
            >
              <span className="sr-only">{translations[language].close}</span>
              ×
            </button>
          </div>
        )}

        {loading ? (
          <div className="flex justify-center items-center h-64">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
          </div>
        ) : (
          <>
            {currentScreen === 'users' && (
              <div className={`p-4 rounded-lg ${settings.darkMode ? 'bg-gray-800' : 'bg-white'} shadow-md`}>
                <div className="mb-4 flex flex-wrap gap-4">
                  <div className="flex-1">
                    <input
                      type="text"
                      placeholder={translations[language].search}
                      value={searchTerm}
                      onChange={handleSearch}
                      className="w-full p-2 border rounded"
                    />
                  </div>
                  <div className="flex gap-2">
                    <input
                      type="date"
                      name="from"
                      value={dateFilter.from}
                      onChange={handleDateFilterChange}
                      className="p-2 border rounded"
                    />
                    <input
                      type="date"
                      name="to"
                      value={dateFilter.to}
                      onChange={handleDateFilterChange}
                      className="p-2 border rounded"
                    />
                    <button
                      onClick={() => setDateFilter({ from: '', to: '' })}
                      className="px-4 py-2 bg-gray-200 rounded hover:bg-gray-300"
                    >
                      {translations[language].reset}
                    </button>
                  </div>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className={`${settings.darkMode ? 'bg-gray-700' : 'bg-gray-50'}`}>
                        <th className="p-2">{translations[language].username}</th>
                        <th className="p-2">{translations[language].email}</th>
                        <th className="p-2">{translations[language].phone}</th>
                        <th className="p-2">{translations[language].church}</th>
                        <th className="p-2">{translations[language].lastConfession}</th>
                        <th className="p-2">{translations[language].lastVisit}</th>
                        <th className="p-2">{translations[language].status}</th>
                        <th className="p-2">{translations[language].actions}</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredUsers.map(user => (
                        <tr key={user.id} className="border-b">
                          <td className="p-2">{user.username}</td>
                          <td className="p-2">{user.email}</td>
                          <td className="p-2">{user.phone}</td>
                          <td className="p-2">{user.churchName}</td>
                          <td className="p-2">
                            {user.lastConfessionDate ? new Date(user.lastConfessionDate).toLocaleDateString(
                              language === 'ar' ? 'ar-EG' : 'en-US'
                            ) : '-'}
                          </td>
                          <td className="p-2">
                            {user.lastVisitationDate ? new Date(user.lastVisitationDate).toLocaleDateString(
                              language === 'ar' ? 'ar-EG' : 'en-US'
                            ) : '-'}
                          </td>
                          <td className="p-2">
                            <span className={`px-2 py-1 rounded ${
                              user.blocked
                                ? 'bg-red-100 text-red-800'
                                : 'bg-green-100 text-green-800'
                            }`}>
                              {user.blocked 
                                ? translations[language].inactive 
                                : translations[language].active}
                            </span>
                          </td>
                          <td className="p-2">
                            <div className="flex space-x-2">
                              <button
                                onClick={() => handleViewAnalytics(user.id)}
                                className="bg-blue-600 text-white px-2 py-1 rounded hover:bg-blue-700"
                              >
                                <ChartBar size={18} className="inline mr-1" />
                                {translations[language].viewAnalytics}
                              </button>
                              <button
                                onClick={() => handleBlockUser(user.id)}
                                className={`${
                                  user.blocked
                                    ? 'bg-green-600 hover:bg-green-700'
                                    : 'bg-yellow-500 hover:bg-yellow-600'
                                } text-white px-2 py-1 rounded`}
                              >
                                {user.blocked 
                                  ? translations[language].unblock 
                                  : translations[language].block}
                              </button>
                              <button
                                onClick={() => handleDeleteUser(user.id)}
                                className="bg-red-600 text-white px-2 py-1 rounded hover:bg-red-700"
                              >
                                {translations[language].delete}
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {currentScreen === 'analytics' && renderUserAnalytics()}

            {currentScreen === 'confession' && (
              <div className={`p-4 rounded-lg ${settings.darkMode ? 'bg-gray-800' : 'bg-white'} shadow-md`}>
                <h2 className="text-2xl font-bold mb-4">{translations[language].confession}</h2>
                
                <div className="mb-4">
                  <button
                    onClick={startCamera}
                    className="bg-blue-600 text-white px-4 py-2 rounded flex items-center"
                    disabled={showCamera}
                  >
                    <Camera className={language === 'ar' ? 'ml-2' : 'mr-2'} size={20} />
                    {translations[language].scanQR}
                  </button>
                </div>

                {showCamera && (
                  <div className="mb-4 p-4 border rounded-lg bg-gray-100">
                    <div className="relative">
                      <video
                        autoPlay
                        playsInline
                        className="w-full max-w-md mx-auto rounded"
                      />
                      <button
                        onClick={stopCamera}
                        className="absolute top-2 right-2 bg-red-600 text-white p-2 rounded"
                      >
                        {translations[language].closeCamera}
                      </button>
                    </div>
                  </div>
                )}

                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className={settings.darkMode ? 'bg-gray-700' : 'bg-gray-50'}>
                        <th className="p-2">{translations[language].username}</th>
                        <th className="p-2">{translations[language].phone}</th>
                        <th className="p-2">{translations[language].email}</th>
                        <th className="p-2">{translations[language].date}</th>
                        <th className="p-2">{translations[language].actions}</th>
                      </tr>
                    </thead>
                    <tbody>
                      {confessionData.map((data, index) => (
                        <tr key={index} className="border-b">
                          <td className="p-2">{data.username}</td>
                          <td className="p-2">{data.phone}</td>
                          <td className="p-2">{data.email}</td>
                          <td className="p-2">
                            {new Date(data.scanDate).toLocaleDateString(
                              language === 'ar' ? 'ar-EG' : 'en-US'
                            )}
                          </td>
                          <td className="p-2">
                            <button
                              onClick={() => {
                                setConfessionData(prev => prev.filter((_, i) => i !== index));
                              }}
                              className="bg-red-600 text-white px-2 py-1 rounded hover:bg-red-700"
                            >
                              {translations[language].delete}
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {currentScreen === 'visitation' && (
              <div className={`p-4 rounded-lg ${settings.darkMode ? 'bg-gray-800' : 'bg-white'} shadow-md`}>
                <h2 className="text-2xl font-bold mb-4">{translations[language].absence}</h2>
                
                <div className="mb-4">
                  <button
                    onClick={startCamera}
                    className="bg-blue-600 text-white px-4 py-2 rounded flex items-center"
                    disabled={showCamera}
                  >
                    <Camera className={language === 'ar' ? 'ml-2' : 'mr-2'} size={20} />
                    {translations[language].scanQR}
                  </button>
                </div>

                {showCamera && (
                  <div className="mb-4 p-4 border rounded-lg bg-gray-100">
                    <div className="relative">
                      <video
                        autoPlay
                        playsInline
                        className="w-full max-w-md mx-auto rounded"
                      />
                      <button
                        onClick={stopCamera}
                        className="absolute top-2 right-2 bg-red-600 text-white p-2 rounded"
                      >
                        {translations[language].closeCamera}
                      </button>
                    </div>
                  </div>
                )}

                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className={settings.darkMode ? 'bg-gray-700' : 'bg-gray-50'}>
                        <th className="p-2">{translations[language].username}</th>
                        <th className="p-2">{translations[language].phone}</th>
                        <th className="p-2">{translations[language].email}</th>
                        <th className="p-2">{translations[language].date}</th>
                        <th className="p-2">{translations[language].actions}</th>
                      </tr>
                    </thead>
                    <tbody>
                      {visitationData.map((data, index) => (
                        <tr key={index} className="border-b">
                          <td className="p-2">{data.username}</td>
                          <td className="p-2">{data.phone}</td>
                          <td className="p-2">{data.email}</td>
                          <td className="p-2">
                            {new Date(data.scanDate).toLocaleDateString(
                              language === 'ar' ? 'ar-EG' : 'en-US'
                            )}
                          </td>
                          <td className="p-2">
                            <button
                              onClick={() => {
                                setVisitationData(prev => prev.filter((_, i) => i !== index));
                              }}
                              className="bg-red-600 text-white px-2 py-1 rounded hover:bg-red-700"
                            >
                              {translations[language].delete}
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </>
        )}
      </main>
    </div>
  );
};

export default AdminDashboard;