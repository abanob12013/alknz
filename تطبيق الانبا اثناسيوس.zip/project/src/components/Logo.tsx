import { useEffect } from 'react';
import { motion, useAnimation } from 'framer-motion';

export const Logo = ({ onClick }: { onClick?: () => void }) => {
  const controls = useAnimation();

  useEffect(() => {
    let isMounted = true;

    const animate = async () => {
      // Wait for next frame to ensure component is mounted
      await new Promise(resolve => requestAnimationFrame(resolve));
      
      if (!isMounted) return;

      while (isMounted) {
        try {
          await controls.start({
            y: [0, -10, 0, 10, 0],
            transition: {
              duration: 4,
              ease: "easeInOut",
              repeat: Infinity,
              repeatType: "loop",
              times: [0, 0.25, 0.5, 0.75, 1]
            }
          });
        } catch (error) {
          // Only log if component is still mounted
          if (isMounted && error instanceof Error) {
            console.error('Animation error:', error.message);
          }
        }
      }
    };

    // Start animation after a short delay to ensure component is mounted
    const timeoutId = setTimeout(animate, 100);

    return () => {
      isMounted = false;
      clearTimeout(timeoutId);
      controls.stop();
    };
  }, [controls]);

  return (
    <motion.div
      className="logo-container"
      onClick={onClick}
      style={{ cursor: onClick ? 'pointer' : 'default' }}
    >
      <motion.img
        initial={{ y: 0 }}
        animate={controls}
        src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEiZutVxxd9wCBgU7lImAcRk4hSQhH0r9x_EquR-vI3Ezbw-zjauccdFrpahnTT8zpfxbVILaVILVVwYDcPbqNYEIrh8CNIKSIWWEmqW0G6Uu23VcI3PXQI9cL_3WZ1VIJ_9ZUJc9MYtHfbdS60hhwU_nGmUIe5QnZV2Bx824ZPlwF7adr05a9Pxt55NfXIo/s600/pngegg%20(1).png"
        alt="Logo"
        className="w-24 h-24 object-contain"
      />
    </motion.div>
  );
};