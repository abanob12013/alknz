import { useState } from 'react';
import { Settings as SettingsType } from '../types';
import { motion } from 'framer-motion';
import { 
  LogOut, 
  Moon, 
  Sun, 
  User, 
  Clock, 
  Lock, 
  UserPlus,
  Languages,
  Eye,
  EyeOff,
  Fingerprint,
  BellRing,
  Palette,
  Settings as SettingsIcon
} from 'lucide-react';

interface Props {
  settings: SettingsType;
  onUpdate: (settings: SettingsType) => void;
  onLogout: () => void;
  onSwitchUser: () => void;
  language?: 'ar' | 'en';
  darkMode?: boolean;
}

export const Settings = ({ settings, onUpdate, onLogout, onSwitchUser, language = 'ar', darkMode = false }: Props) => {
  const [showPasswordChange, setShowPasswordChange] = useState(false);
  const [passwordData, setPasswordData] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  });

  const handlePasswordChange = (e: React.FormEvent) => {
    e.preventDefault();
    if (passwordData.newPassword !== passwordData.confirmPassword) {
      alert(language === 'ar' ? 'كلمات المرور غير متطابقة' : 'Passwords do not match');
      return;
    }
    alert(language === 'ar' ? 'تم تغيير كلمة المرور بنجاح' : 'Password changed successfully');
    setShowPasswordChange(false);
    setPasswordData({
      currentPassword: '',
      newPassword: '',
      confirmPassword: ''
    });
  };

  const handleFontSizeChange = (size: number) => {
    onUpdate({ ...settings, fontSize: size });
  };

  const handleLanguageChange = (lang: 'ar' | 'en') => {
    onUpdate({ ...settings, language: lang });
  };

  const handleBiometricsToggle = async () => {
    if (!settings.useBiometrics) {
      try {
        if (!window.PublicKeyCredential) {
          alert(language === 'ar' 
            ? 'المتصفح لا يدعم المصادقة البيومترية' 
            : 'Browser does not support biometric authentication');
          return;
        }

        const available = await PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable();
        if (!available) {
          alert(language === 'ar'
            ? 'المصادقة البيومترية غير متوفرة على هذا الجهاز'
            : 'Biometric authentication is not available on this device');
          return;
        }
      } catch (error) {
        console.error('Biometric check failed:', error);
        return;
      }
    }
    
    onUpdate({ ...settings, useBiometrics: !settings.useBiometrics });
  };

  const handleDarkModeToggle = () => {
    onUpdate({ ...settings, darkMode: !settings.darkMode });
  };

  const [dateTime, setDateTime] = useState(new Date());

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className={`${darkMode ? 'bg-gray-800' : 'bg-white'} rounded-lg shadow-md p-6`}
    >
      <h2 className={`text-2xl font-bold mb-6 ${language === 'ar' ? 'text-right' : 'text-left'}`}>
        <SettingsIcon className={`inline ${language === 'ar' ? 'ml-2' : 'mr-2'}`} size={24} />
        {language === 'ar' ? 'الإعدادات' : 'Settings'}
      </h2>

      <div className="space-y-6">
        <div>
          <h3 className={`text-lg font-semibold mb-3 ${language === 'ar' ? 'text-right' : 'text-left'}`}>
            <Palette className={`inline ${language === 'ar' ? 'ml-2' : 'mr-2'}`} size={20} />
            {language === 'ar' ? 'المظهر' : 'Appearance'}
          </h3>
          <div className="flex justify-between items-center">
            <button
              onClick={() => onUpdate({ ...settings, darkMode: !settings.darkMode })}
              className={`flex items-center space-x-2 px-4 py-2 rounded-lg ${
                darkMode 
                  ? 'bg-gray-700 text-white hover:bg-gray-600' 
                  : 'bg-gray-100 text-gray-800 hover:bg-gray-200'
              }`}
            >
              {darkMode ? <Moon className={`${language === 'ar' ? 'ml-2' : 'mr-2'}`} /> : <Sun className={`${language === 'ar' ? 'ml-2' : 'mr-2'}`} />}
              <span>{darkMode ? (language === 'ar' ? 'الوضع الليلي' : 'Dark Mode') : (language === 'ar' ? 'الوضع النهاري' : 'Light Mode')}</span>
            </button>
          </div>
        </div>

        <div>
          <h3 className={`text-lg font-semibold mb-3 ${language === 'ar' ? 'text-right' : 'text-left'}`}>
            <Languages className={`inline ${language === 'ar' ? 'ml-2' : 'mr-2'}`} size={20} />
            {language === 'ar' ? 'اللغة' : 'Language'}
          </h3>
          <select
            value={settings.language}
            onChange={(e) => handleLanguageChange(e.target.value as 'ar' | 'en')}
            className={`w-full p-2 border rounded-lg ${language === 'ar' ? 'text-right' : 'text-left'}`}
            dir={language === 'ar' ? 'rtl' : 'ltr'}
          >
            <option value="ar">العربية</option>
            <option value="en">English</option>
          </select>
        </div>

        <div>
          <h3 className={`text-lg font-semibold mb-3 ${language === 'ar' ? 'text-right' : 'text-left'}`}>
            <Lock className={`inline ${language === 'ar' ? 'ml-2' : 'mr-2'}`} size={20} />
            {language === 'ar' ? 'الأمان' : 'Security'}
          </h3>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <label className="flex items-center space-x-2">
                <Fingerprint className={`${language === 'ar' ? 'ml-2' : 'mr-2'}`} size={20} />
                <input
                  type="checkbox"
                  checked={settings.useBiometrics}
                  onChange={handleBiometricsToggle}
                  className="form-checkbox h-5 w-5 text-blue-600"
                />
                <span>{language === 'ar' ? 'تفعيل البصمة' : 'Enable Biometrics'}</span>
              </label>
            </div>
            
            <button
              onClick={() => setShowPasswordChange(!showPasswordChange)}
              className="flex items-center space-x-2 text-blue-600 hover:text-blue-700"
            >
              <Lock size={18} className={`${language === 'ar' ? 'ml-2' : 'mr-2'}`} />
              <span>{language === 'ar' ? 'تغيير كلمة المرور' : 'Change Password'}</span>
            </button>

            {showPasswordChange && (
              <form onSubmit={handlePasswordChange} className="space-y-3">
                <input
                  type="password"
                  placeholder={language === 'ar' ? 'كلمة المرور الحالية' : 'Current Password'}
                  value={passwordData.currentPassword}
                  onChange={(e) => setPasswordData({ ...passwordData, currentPassword: e.target.value })}
                  className="w-full p-2 border rounded-lg"
                  dir={language === 'ar' ? 'rtl' : 'ltr'}
                />
                <input
                  type="password"
                  placeholder={language === 'ar' ? 'كلمة المرور الجديدة' : 'New Password'}
                  value={passwordData.newPassword}
                  onChange={(e) => setPasswordData({ ...passwordData, newPassword: e.target.value })}
                  className="w-full p-2 border rounded-lg"
                  dir={language === 'ar' ? 'rtl' : 'ltr'}
                />
                <input
                  type="password"
                  placeholder={language === 'ar' ? 'تأكيد كلمة المرور الجديدة' : 'Confirm New Password'}
                  value={passwordData.confirmPassword}
                  onChange={(e) => setPasswordData({ ...passwordData, confirmPassword: e.target.value })}
                  className="w-full p-2 border rounded-lg"
                  dir={language === 'ar' ? 'rtl' : 'ltr'}
                />
                <button
                  type="submit"
                  className="w-full bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700"
                >
                  {language === 'ar' ? 'تحديث كلمة المرور' : 'Update Password'}
                </button>
              </form>
            )}
          </div>
        </div>

        <div>
          <h3 className={`text-lg font-semibold mb-3 ${language === 'ar' ? 'text-right' : 'text-left'}`}>
            <Clock className={`inline ${language === 'ar' ? 'ml-2' : 'mr-2'}`} size={20} />
            {language === 'ar' ? 'الوقت والتاريخ' : 'Date & Time'}
          </h3>
          <div className="flex items-center space-x-2 mb-4">
            <Clock size={18} className={`${language === 'ar' ? 'ml-2' : 'mr-2'}`} />
            <span>
              {dateTime.toLocaleString(language === 'ar' ? 'ar-EG' : 'en-US', {
                weekday: 'long',
                year: 'numeric',
                month: 'long',
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit',
                second: '2-digit'
              })}
            </span>
          </div>
        </div>

        <div className="pt-6 border-t space-y-4">
          <button
            onClick={onSwitchUser}
            className={`w-full flex items-center justify-center space-x-2 ${
              darkMode 
                ? 'bg-blue-600 hover:bg-blue-700' 
                : 'bg-blue-500 hover:bg-blue-600'
            } text-white py-2 rounded-lg`}
          >
            <UserPlus className={`${language === 'ar' ? 'ml-2' : 'mr-2'}`} size={20} />
            <span>{language === 'ar' ? 'تبديل المستخدم' : 'Switch User'}</span>
          </button>

          <button
            onClick={onLogout}
            className="w-full flex items-center justify-center space-x-2 bg-red-600 text-white py-2 rounded-lg hover:bg-red-700"
          >
            <LogOut className={`${language === 'ar' ? 'ml-2' : 'mr-2'}`} size={20} />
            <span>{language === 'ar' ? 'تسجيل الخروج' : 'Logout'}</span>
          </button>
        </div>
      </div>
    </motion.div>
  );
};