import { motion } from 'framer-motion';
import { Task } from '../types';
import { Coins, Check } from 'lucide-react';

interface Props {
  tasks: Task[];
  onTaskComplete: (taskId: number) => void;
  language?: 'ar' | 'en';
  darkMode?: boolean;
  coinAnimation?: boolean;
}

const taskImages = [
  "https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEhAxDvDdyHvxdBigTgRMBJ_8WZFIvGNduIEm1LZ6aisJNoHsESDpj1cV7zIkNZb7MQm1GCHzg3wDj4PRntYhQ7Ndigk6PPS4QlGBWQCUWvMCKrtTe0grOcyU3LDhWgDuUYpyjmg9ITBaEYOpCiHHnQRsrVryxw5e3tCoN7YJGY7lJLnqjCmLIQnLLvuP-Gv/s103/0.1.%20(1).png",
  "https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgeOS3bMbznd2xQQWQ2x22Ahkv0bDFAb2M75-gn7L0xG_QSmDOQLmYRWgteBas3ElZYl-7ijhqdMrj2R_iN-Zn741wcpPn-PDxN_AkEy5d0YpwO7iOVhzHAqnWwepsPLPpZ8TVtHbdVcEYUHUJxFpAIbjkMtqXCRnkfCrDfYkc4G1r_qEMhb8I-TleA3YZm/s103/0.2.%20(3).png",
  "https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgeIVpKchokfy5H1wbvOI5Y77CfycRB5m4yDoqu56hRtOuoOtcJIWBSC8Ujb1bEAMoEkMv3QiMlHNE8xawHKf7-nokGKQfisXwhgwWWmZSaE2bkjMIgzn1ZjMK8mBEquondgp5QMqoqIlWUmTq6lPXcB8MyMtYCt98VFLhXQy3aavB6ipQLSwS-TT4TYPv1/s103/0.3.%20(1).png",
  "https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEhQzxL7T4qnrpBCMcnrqtR7MocelLUg4V_5qV80jIQzNgDYeTXwCAeMWo6R4PESMFVfS0MvkElEzRaC2ksuUg5c98esq0NkiVlPFfV6y7ouxfT0T30GmBNKOn9pTbKpmWjgBgQc1NfyR8JyzmO4s_vbBu4dJmyrIn5RNla_Edh14RVG5pSbDGQLeGl29Key/s103/0.4.%20(1).png",
  "https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgHPaz6w1Zd4I4KRtJMw1ywbLRi4l2dvHwOJC3_0W1tsuZKtVL50jaDMeTPK4wqxX-VfUN-y6wqX5oh3IHf08IXN8SxPMNK7f4ejY8Fsm_VDe0rE_uy1O5ujx7dWBkhoQgupNDlS7K2Ojb-h_BOcviZhvLrDB02TS54oF0ZHdUkP3Pmcj9urgspSpXgnn4D/s103/0.5%20(1).png",
  "https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEiLppchG9xPJIQd93oIOZLwFDxfkSViQL6dvSM-zfua7A8werN50I2lghQAyq6FGJNJuKvAM5KKKy1CPQ3fKmxza2Vc5hhC5IjhVIjdSEKhWhgyxSKWAZbZzecJFXBxJ1pIp4fqQQ8M2jU4HVDjiTS05ZGRczhTfaSmJwGC1D7sDjESanpWmt2z-ym2UOzL/s103/0.6%20(2).png",
  "https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjxrew8l4g8L1brz8e65Y4JgNC4SF8EL4mLuXb_T7bTNNbLbuI1RzaA26eUYSusiPrY5QHXU_W6CLd05HsSTOdraUat1MjSf3uAXqXE_52ydQ73dDLBHWEwquxeBksi_4Msayzj23sxOdGIHtGsg5KkN2w3pYlELLbfw6rDkpd56UXXYr-M88KuC_UQOAQc/s103/0.7.%20(1).png",
  "https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEiCe63UCMnd8_8Z0JkxYYSeVl4sI4_fihubDs5kUE04y-cS0lRK1sml3WjeCN1VEYAnwMJ-e16KdS9iNrq-LpNyI-tSNaQJzoLNVIOhWd_T8HQ0KWSW9f6_nX4kBoYpIiWt2Kkc9GIO8ayDGM4g0_8MW32hPN0GkrP4M2yF9v1YXd4-PuG-ApYAuITmWjgL/s103/0.8.%20(2).png",
  "https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjArgxwx4i2GFs59keZJgeqJ0nC8r-cTMDC3ZwUgpdyBGAx4XOdU61EcbF7glXdNswgg3w2j73cGSZ4QwvKOG3SsaPz2jre7bKEL_8zHX5I6OSnVtntfGJeY33AbGoQnPs3HzjgRK88knlVqObdPtT1UrkTn2qJx5kiP1r3oOB9iZB46hAMsHsRDUA-axe5/s103/0.9%20(1).png",
  "https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgoqD9vZTt2y58exSun9RetMN1fTn3ZTilWJrlQF6Yt5xZKziJ9x8t_f55aF2UsMCx_flsQzNZhTgfgbGlymDwlQcPdy3dWDs_yNRLF4fdxX2PXKn93vxfiGXBaO4r7CcrHzhHKv4Qhe4cwXX4c10Yh304_9NLKt94snZ-9kyYAvVvXEDhJ8zs20t6WU3o9/s103/0.10%20(1).png",
  "https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjWVxZMUQDiovnbk2XuUUzZj7_0xcHXxGs47j3t2ZwKr-D4NeG7ThcQhzRsWI7XBGHOJLMYu8UFe7YuqUrtiepAW1RlHjiXfxwCiS-Vf2CBYuv1Hbncoc4L_2cQkAOiOWToc9WF0ON8eHO7q_XfJv3ZAfKHsEIyckuPtGrGC3jb8WP0rUYgGCg7BCWdjGW7/s103/0.12%20(1).png",
  "https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjuMd-b-vKcuG5vx5DElvk6zUL63BOZ1J8sAOGkVbL9bLnAJSGDxtpDM1Dk4QYS38f0iARiZ1tkn1Pdbo2xvkPmoEtGwTamqueHSbYngVGhyLGvYNBGxulWhLF2sg2MUt4ZjDA6ZIHRUZZ6Tkqdknb0Kptw3nf82-SXVs8JFd5VB-D45_BDqIzuej4E0_8W/s103/0.13%20(1).png",
  "https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgxPCCOf5oAOIndZYpbpCDXCyGpJ2ahGXrMJhXPFqdgm44kLwNLXPed-zrcQ6xIBew7dI0pcYqv1HREsIWFjifT2b3JJ7-sO1w47vGMGfeh-4wCtWJh9_jGcpTY_b7wum_FVQDBoIuLyReV9XbB3BznbBnUD2fhZjTswW5eVF8p9SQkF82pi2hbt_xQx41n/s103/0.15%20(1).png",
  "https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEhWjl5PjIlSClLFd7IdPJGvgSYXcusOq4A78KgLxVxtZKPkrrxciX0Ir44KFEl4F-1A_BpRe8bJaigCWyHg17ZsJNoYzDOn1noRKYpf0ynaXLOS6Fl4rtiz1kXEM-JQzdsLSjy12rbq1410EhuGKw-xoiz0g1efe9hn9Ue0Eu0CbQlXP7VNjaPzdTfyUPSl/s103/0.14%20(1).png",
  "https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEhv48uyrPz54z7zmlj-Qq5qldGG-39bK_gzLVdvzkQlrUX-yD1548pZc73EbosDG8GvvLIIjGQvCVuG4moEA0j9EMhz-l_5GMxoc1MOaFFYltvrnoLO3KNv8MxZLIh6pZ0-9PGPMJtgGZVEH-UYhz_RtZwmejxkmGxiI9uAc_XjIiyAyPDoXb2TqtFlj6uf/s103/0.16%20(1).png",
  "https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgjVWlCiVVdT45eS_uoIAQkuPxWi1EgQT7HqvmEX2yLxPgOAL5UCXHgWKML6gcQ-3UbcsRDEENnQ6PpcbDRaCVsv-oz-LnTFkerDk8_XeeDT4jLLmRtsEOeVX-SurTk6BEvUhL0TFNuL8iDj7UD0iDqTYQ62nhr-i96zMA9cg-fl_NmDB4inCs2IhhS4W8f/s103/0.11%20(2).png",
  "https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjIyn-TimCgwUWO0ISZLrlrPn_s5A-3voQMLrVRE-TMtIxvUbrc0rXiYXHV7bcdgQfBhTfjLCVzRvFsw1oDw-2O5j47EDKuYTKX4xO3Dwl0cgl9F53GwxGlxw5_FbKVvt_D1N9UzwGl4ehVGd4kDe1OHnCyyBW_px8CIDwkgMh22SEBLc4hG68M7GIhHP_V/s103/0.17%20(1).png"
];

const taskPoints = [1, 1, 1, 1, 1, 1, 1, 5, 10, 3, 7, 2, 1, 6, 8, 5, 2];

const taskNames = {
  ar: [
    'صلاة باكر',
    'صلاة الساعة الثالثة',
    'صلاة الساعة السادسة',
    'صلاة الساعة التاسعة',
    'صلاة الغروب',
    'صلاة النوم',
    'قراءة الكتاب المقدس',
    'حضور القداس',
    'صوم انقطاعي',
    'ميطانيات',
    'تحمل الآخرين',
    'حفظ ألحان أو ترانيم',
    'الاعتراف',
    'صلاة يسوع',
    'الخدمة في الكنيسة',
    'أعمال رحمة',
    'حضور التسبحة'
  ],
  en: [
    'Morning Prayer',
    'Third Hour Prayer',
    'Sixth Hour Prayer',
    'Ninth Hour Prayer',
    'Vespers Prayer',
    'Compline Prayer',
    'Bible Reading',
    'Attending Mass',
    'Fasting',
    'Metanoia',
    'Bearing Others',
    'Learning Hymns',
    'Confession',
    'Jesus Prayer',
    'Church Service',
    'Acts of Mercy',
    'Attending Praise'
  ]
};

export const TaskGrid = ({ tasks = [], onTaskComplete, language = 'ar', darkMode = false, coinAnimation = false }: Props) => {
  const canCompleteTask = (task: Task) => {
    if (!task.lastCompletedAt) return true;
    
    const lastCompletionTime = new Date(task.lastCompletedAt).getTime();
    const currentTime = new Date().getTime();
    const hoursSinceLastCompletion = (currentTime - lastCompletionTime) / (1000 * 60 * 60);
    
    return hoursSinceLastCompletion >= 24;
  };

  const getTimeRemaining = (task: Task) => {
    if (!task.lastCompletedAt) return null;
    
    const lastCompletionTime = new Date(task.lastCompletedAt).getTime();
    const currentTime = new Date().getTime();
    const hoursSinceLastCompletion = (currentTime - lastCompletionTime) / (1000 * 60 * 60);
    
    if (hoursSinceLastCompletion >= 24) return null;
    
    const hoursRemaining = Math.ceil(24 - hoursSinceLastCompletion);
    return language === 'ar'
      ? `متبقي ${hoursRemaining} ساعة`
      : `${hoursRemaining} hours remaining`;
  };

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 p-4">
      {tasks.map((task, index) => {
        const isAvailable = canCompleteTask(task);
        const timeRemaining = getTimeRemaining(task);
        const taskPoint = taskPoints[index] || task.points;

        return (
          <motion.div
            key={task.id}
            whileHover={{ scale: isAvailable ? 1.05 : 1 }}
            whileTap={{ scale: isAvailable ? 0.95 : 1 }}
            className={`task-card p-4 rounded-lg shadow-md ${
              !isAvailable
                ? (darkMode ? 'bg-gray-700 cursor-not-allowed' : 'bg-gray-100 cursor-not-allowed')
                : task.completed 
                  ? (darkMode ? 'bg-green-800 cursor-pointer' : 'bg-green-100 cursor-pointer')
                  : (darkMode ? 'bg-gray-800 cursor-pointer' : 'bg-white cursor-pointer')
            }`}
            onClick={() => isAvailable && onTaskComplete(task.id)}
          >
            <div className="relative">
              <img
                src={taskImages[index] || task.imageUrl}
                alt={`Task ${task.id}`}
                className={`w-full h-auto rounded mb-2 ${!isAvailable ? 'opacity-50' : ''}`}
              />
              {task.completed && (
                <div className="absolute top-2 right-2 bg-green-500 rounded-full p-1">
                  <Check className="text-white" size={16} />
                </div>
              )}
            </div>
            <div className="text-center space-y-2">
              <div className="flex items-center justify-center">
                <Coins 
                  className={`text-yellow-500 ${language === 'ar' ? 'ml-1' : 'mr-1'} ${
                    coinAnimation && isAvailable ? 'animate-bounce' : ''
                  }`} 
                  size={18} 
                />
                <span className={`font-bold text-lg ${darkMode ? 'text-white' : 'text-gray-800'}`}>
                  {taskPoint}
                </span>
              </div>
              <p className={`text-xl font-bold ${darkMode ? 'text-white' : 'text-gray-800'}`}>
                {taskNames[language][index]}
              </p>
              {timeRemaining && (
                <p className={`text-sm ${darkMode ? 'text-red-300' : 'text-red-600'}`}>
                  {timeRemaining}
                </p>
              )}
              {task.lastCompletedAt && (
                <p className={`text-sm ${darkMode ? 'text-gray-300' : 'text-gray-600'}`}>
                  {language === 'ar' ? 'آخر تنفيذ:' : 'Last completed:'}{' '}
                  {new Date(task.lastCompletedAt).toLocaleString(
                    language === 'ar' ? 'ar-EG' : 'en-US',
                    {
                      year: 'numeric',
                      month: 'short',
                      day: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit'
                    }
                  )}
                </p>
              )}
            </div>
          </motion.div>
        );
      })}
    </div>
  );
};