export interface User {
  id: string;
  username: string;
  email: string;
  phone: string;
  churchName: string;
  confessorName: string;
  dateOfBirth: string;
  profilePicture?: string;
  notifications?: Message[];
  settings?: Settings;
  points?: number;
  dailyData?: DailyAnalysis[];
}

export interface Task {
  id: number;
  points: number;
  imageUrl: string;
  completed: boolean;
  lastCompletedAt?: string;
  name?: {
    ar: string;
    en: string;
  };
}

export interface DailyAnalysis {
  date: string;
  points: number;
  completedTasks?: number[];
  taskNames?: {
    taskId: number;
    userId: string;
    username: string;
  }[];
}

export interface Settings {
  fontSize: number;
  language: 'ar' | 'en';
  useBiometrics: boolean;
  darkMode: boolean;
}

export interface AuthState {
  isAuthenticated: boolean;
  user: User | null;
  isAdmin: boolean;
}

export interface Message {
  id: string;
  spiritualMessage: string;
  notification: string;
  timestamp: string;
  read: boolean;
  sender?: string;
  recipient?: string;
}